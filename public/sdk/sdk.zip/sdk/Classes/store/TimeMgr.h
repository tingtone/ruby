#import <Foundation/Foundation.h>

@interface TimeMgr : NSObject {
    NSTimer* _track_timer;
    long long weekday_left_time;
    long long weekend_left_time;
    long long pause_left;
    long long break_left;
}

+(TimeMgr*)instance;
-(void) resetPauseBreak;
-(void) resetWeekWeekend;
-(void) startTimer;
-(void) stopTimer;
-(void) postTime;
-(void) startBreak;
-(void) startPause;
@end
