
#import "TimeMgr.h"
#import "Kittypad.h"
#import "Kittypad+internal.h"
#import "KPData.h"
#import "KittypadDelegate.h"
#import "ASIFormDataRequest.h"

static TimeMgr* _instance = nil;

@implementation TimeMgr

+(TimeMgr*)instance{
    @synchronized(self)
    {
    if (!_instance)
       _instance= [[self alloc] init];
    }
    return _instance;
}

-(id)init {
	self = [super init];
	if (self != nil) {
	}
	return self;
}

- (void) handleTimer: (NSTimer *) timer
{
    
    NSInteger weekday = [Kittypad getWeekday];
    if (weekday == 7 || weekday == 1) {
        if(weekend_left_time <= 0){
            NSLog(@"weekend: Stop the game like hell");
            [[TimeMgr instance] postTime];
            [[Kittypad getDelegate]onClose:nil];
            return;
        }
    }
    else {
        if(weekday_left_time<=0){
            NSLog(@"weekday: Stop the game like hell");
            [[TimeMgr instance] postTime];
            [[Kittypad getDelegate]onClose:nil];
            return;
        } 
    }
    
    if(pause_left <=0)
    {
        [self startPause];
        return;
    }
    
    if(break_left<= 0){
        [self startBreak];
        return;
    }
    
    NSString* message = [NSString stringWithFormat: @"weekday_left_time is %lld,\n\
                         weekend_left_time is %lld,\n \
                         break_left is %lld,\n\
                         pause_left is %lld\n"
                         , weekday_left_time, weekend_left_time,break_left, pause_left];
    NSLog(@"%@", message);
    
    
    // sat or sun
    if (weekday == 7 || weekday == 1) {
        weekend_left_time--;
    }
    else {
        weekday_left_time--;
    }
    pause_left--;
    break_left--;
} 

-(void) startTimer
{
    if ([[KPData instance] getKPValue:kEmail] == nil) {
        return;
    }
        
    if(_track_timer!=nil)
    {
        NSLog(@"timer already began, do nothing");
    }
    else
    {
        weekday_left_time = [((NSNumber*)[[KPData instance] getKPValue:kWeekday_time_left])longLongValue];
        weekend_left_time = [((NSNumber*)[[KPData instance] getKPValue:kWeekend_time_left])longLongValue];
        break_left = [((NSNumber*)[[KPData instance] getKPValue:kInteval_break_left])longLongValue];
        pause_left = [((NSNumber*)[[KPData instance] getKPValue:kInteval_pause_left])longLongValue];
       
        NSString* message = [NSString stringWithFormat: @"weekday_left_time is %lld,\
                             weekend_left_time is %lld, \
                             break_left is %lld,\
                             pause_left is %lld"
                             , weekday_left_time, weekend_left_time,break_left, pause_left];
        NSLog(@"%@", message);
        _track_timer = [NSTimer scheduledTimerWithTimeInterval: 1
                                                   target: self
                                                 selector: @selector(handleTimer:)
                                                 userInfo: nil
                                                repeats: YES];
    }
}


-(void) stopTimer{
    [[KPData instance] setKPValue:[NSNumber numberWithLongLong:weekday_left_time] withKey:kWeekday_time_left];
    [[KPData instance] setKPValue:[NSNumber numberWithLongLong:weekend_left_time] withKey:kWeekend_time_left];
    [[KPData instance] setKPValue:[NSNumber numberWithLongLong:pause_left] withKey:kInteval_pause_left];
    [[KPData instance] setKPValue:[NSNumber numberWithLongLong:break_left] withKey:kInteval_break_left];
    if(_track_timer!=nil){
        [_track_timer invalidate];
        _track_timer = nil;
    }
    
    NSLog(@"timer stop");
}

-(void)startBreak{
    if ([[KPData instance] getKPValue:kEmail] == nil) {
        return;
    }
    [self stopTimer];
    NSLog(@"start Break!");
    [Kittypad showPause:2];
    [[KPData instance]setKPValue:[[KPData instance] getKPValue:kInteval_break] withKey:kInteval_break_left];
}

-(void)startPause{
    if ([[KPData instance] getKPValue:kEmail] == nil) {
        return;
    }
    [self stopTimer];
    NSLog(@"start Pause!");
    [Kittypad showPause:1];
    [[KPData instance]setKPValue:[[KPData instance] getKPValue:kInteval_pause] withKey:kInteval_pause_left];    
}

-(void) postTime{
    NSLog(@"start postTime!");
    
    if ([[KPData instance] getKPValue:kEmail] == nil) {
        return;
    }
    
    [self stopTimer];
    
    //post form device_identifier=abcd-efgh-ijkl&time=60&time_to_pause=1&time_to_break=2
    
    NSMutableDictionary* pendingData = [NSMutableDictionary dictionaryWithCapacity:20];
    
    //device id;
    NSString *udid = [[UIDevice currentDevice] uniqueIdentifier];
    [pendingData setObject:udid forKey:@"device_identifier"];
    [pendingData setObject:[Kittypad getKey] forKey:@"key"];
    [pendingData setObject:[NSNumber numberWithLongLong:pause_left] forKey:@"time_to_pause"];
    [pendingData setObject:[NSNumber numberWithLongLong:break_left] forKey:@"time_to_break"];
    
    NSInteger weekday = [Kittypad getWeekday];
    // sat or sun
    if (weekday == 7 || weekday == 1) {
        NSLog(@"postTime time_left = %@", [NSNumber numberWithLongLong:weekend_left_time]);
        [pendingData setObject:[NSNumber numberWithLongLong:weekend_left_time] forKey:@"time_left"];
    }
    else {
        NSLog(@"postTime time_left = %@", [NSNumber numberWithLongLong:weekday_left_time]);
        [pendingData setObject:[NSNumber numberWithLongLong:weekday_left_time] forKey:@"time_left"]; 
    }
    
    NSTimeInterval interval = [[NSDate date] timeIntervalSince1970]; 
    NSString *dateStr = [NSString stringWithFormat:@"%.0f", interval];
    [pendingData setObject:dateStr forKey:kLastUpdate];
    
    NSString* path = @"api/v1/time_trackers.json";
    NSMutableString *urlBuf = [[NSMutableString alloc]init];
    [urlBuf appendString:[Kittypad getServerUrl]];
    [urlBuf appendString:path];
    NSURL* url =[NSURL URLWithString:urlBuf];
    NSString* secret = [Kittypad getSecret];
    ASIFormDataRequest  *request = [[[ASIFormDataRequest alloc] initWithURL:url] autorelease];
    request = [[KPData instance] addRequestWithDitionary:request withDictionary:pendingData];
    NSString* sig = [[[KPData instance] getSignitureWithPath:@"/api/v1/time_trackers.json" secret:secret method:@"POST" query:pendingData]retain];
    
    [request addPostValue:sig forKey:@"signature"];
    [request setDelegate:self];
    [request startSynchronous];
    
    [urlBuf release];}

- (void)requestFailed:(ASIHTTPRequest *)request
{
    NSError *error = [request error];
    NSLog(@"%@",[error description]);
    
}

- (void)requestFinished:(ASIHTTPRequest *)request
{
    // Use when fetching text data
    NSString *responseString = [request responseString];
    NSLog(@"%@", responseString);
    
    // Use when fetching binary data
    NSData *responseData = [request responseData];
    NSLog(@"%@", responseData);
}

-(void) resetPauseBreak{
    [[KPData instance]setKPValue:[[KPData instance] getKPValue:kInteval_break] withKey:kInteval_break_left];
    [[KPData instance]setKPValue:[[KPData instance] getKPValue:kInteval_pause] withKey:kInteval_pause_left];
}

-(void) resetWeekWeekend{
    [[KPData instance]setKPValue:[[KPData instance] getKPValue:kWeekday_time] withKey:kWeekday_time_left];
    [[KPData instance]setKPValue:[[KPData instance] getKPValue:kWeekend_time] withKey:kWeekend_time_left];
}

@end
