
#import "Kittypad+internal.h"
#import "TimeMgr.h"
#import "Reachability.h"
#import "KPData.h"
#import "KPPostScore.h"

@interface Kittypad (privateInterface)
+(NSDictionary *)loadConfigure:(NSString*)plist;
@end

@implementation Kittypad

+ (void) initializeWithPlist:(NSString*)plist 
                 andDelegate:(id<KittypadDelegate>)delegate {
    NSDictionary *temp =[Kittypad loadConfigure:plist];
	[Kittypad initializeProductKey:[temp objectForKey:@"app_key"]
							 andSecret:[temp objectForKey:@"app_secret"]
                             serverUrl:[temp objectForKey:@"server"]
						   andDelegate:delegate];
}

+(NSDictionary *)loadConfigure:(NSString*)plist{
    
    NSString *errorDesc = nil;
    NSPropertyListFormat format;
    NSString *plistPath;

    plistPath = [[NSBundle mainBundle] pathForResource:plist ofType:@"plist"];
    NSData *plistXML = [[NSFileManager defaultManager] contentsAtPath:plistPath];
    NSDictionary *temp = (NSDictionary *)[NSPropertyListSerialization
                                          propertyListFromData:plistXML
                                          mutabilityOption:NSPropertyListMutableContainersAndLeaves
                                          format:&format
                                          errorDescription:&errorDesc];
    if (!temp) {
        NSLog(@"Error reading plist: %@, format: %d", errorDesc, format);
    }
    
    NSLog(@"app_key:%@",[temp objectForKey:@"app_key"]);
    NSLog(@"app_secret:%@",[temp objectForKey:@"app_secret"]);
    NSLog(@"server:%@",[temp objectForKey:@"server"]);
    return temp;
}

+ (void) shutdown
{
	[[TimeMgr instance]postTime];
}

+ (void) start {
    [[TimeMgr instance]stopTimer];
    [Kittypad presentDashboard];
}


+ (void) setDashboardOrientation:(UIInterfaceOrientation)orientation
{
    [Kittypad setDashboardOrientationInternal:orientation];
}

+ (void) postScore:(NSInteger) score{
    NSLog(@"post log form app");
    [[KPPostScore instance]post_score:score];
}

+ (void) setBackButtonHidden:(BOOL)isHidden {
    [Kittypad setBackButtonHiddenInternal:isHidden];
}

+ (void) setBreakDelegate:(id<KittypadBreakDelegate>)delegate {
    [Kittypad setBreakDelegateInternal:delegate];
}

@end
