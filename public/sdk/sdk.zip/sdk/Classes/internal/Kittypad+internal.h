#import <Foundation/Foundation.h>
#import "KittypadDelegate.h"
#import "KittypadBreakDelegate.h"
#import "KRootController.h"
#import "Kittypad.h"

@interface Kittypad (internal)

////////////////////////////////////////////////////////////
///
/// @param productKey is copied. This is your unique product key you received when registering your application.
/// @param productSecret is copied. This is your unique product secret you received when registering your application.
/// @param delegatesContainer is retained but none of the delegates in the container are retained. 
///
/// @note This will begin the application authorization process.
///
////////////////////////////////////////////////////////////
+ (void) initializeProductKey:(NSString*)productKey 
						andSecret:(NSString*)secret

                    serverUrl:(NSString*)server
					 andDelegate:(id<KittypadDelegate>)delegate;
+ (NSString*) getKey;
+ (NSString*) getSecret;
+ (NSString*) getServerUrl;

+ (void) showController:(UIViewController*) child;

+ (void) pushController:(UIViewController*) controller;

+ (void) popController;

+(void)showPause:(int)viewType;

+ (NSBundle*)getResourceBundle;
+(void)tryCreateDashboard;

+(void)presentDashboard;
+(void)dismissDashboard;
+ (void)transformViewToDashboardOrientation:(UIView*)view;
+ (void)transformView:(UIView*)view toOrientation:(UIInterfaceOrientation)orientation;

+ (CGRect)getDashboardBounds;

////////////////////////////////////////////////////////////
///
/// Sets what orientation the dashboard and notifications will show in.
///
////////////////////////////////////////////////////////////
+ (void) setDashboardOrientationInternal:(UIInterfaceOrientation)orientation;

+ (UIInterfaceOrientation)getDashboardOrientationInternal;

+ (id<KittypadDelegate>) getDelegate;


+ (void) generateKittypadButtonInternalX:(float) x Y:(float)y;

+ (UITabBarController*) getTabController;

+ (NSInteger) getWeekday;

+ (void) setBackButtonHiddenInternal:(BOOL)isHidden;
+ (BOOL) getBackButtonHiddenInternal;

+ (void) setBreakDelegateInternal:(id<KittypadBreakDelegate>)delegate;
+ (id<KittypadBreakDelegate>) getBreakDelegate;

@end
