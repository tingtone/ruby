
#import "KPRequest.h"
#import "ASIHTTPRequest.h"
#import "ASIFormDataRequest.h"
#import "KPLog.h"
#import "Kittypad+internal.h"
#include "hmac.h"
#include "Base64Transcoder.h"
#import "CJSONDeserializer.h"

#pragma mark Private KPRequest methods

@interface KPRequest ()
@property (nonatomic, retain) ASIHTTPRequest* request;
@property (nonatomic, retain) id<KPResponseText> responseText;
@property (nonatomic, retain) id<KPResponseData> responseData;
@property (nonatomic, retain) id<KPResponseJSON> responseJSON;
@property (nonatomic, retain) NSString* responseAsString;
@property (nonatomic, retain) NSObject* responseAsJson;
@property (nonatomic, retain) NSData* responseAsData;
@property (nonatomic, retain) NSString* path;
- (void)requestFinishedOnRequestThread;
@end

#pragma mark ASIHTTPRequest extensions

// In lieu of modules, we are just going to derive from ASIHTTPRequest and ASIFormDataRequest, overriding the
// -requestFinished method.  This allows us to do the parsing functionality off the main thread, before the
// delegates get invoked.  Also, we have a protocol, just so that we can be assured the subclasses we're using
// are compatible with this behavior.

@interface ExtendedGetRequest : ASIHTTPRequest <ExtendedRequest>
{
    KPRequest* kpRequest;
}
@end

@implementation ExtendedGetRequest
- (void)setKPRequest:(KPRequest*)_request
{
    [kpRequest release];
    kpRequest = [_request retain];
}
- (void)requestFinished
{
    [kpRequest requestFinishedOnRequestThread]; 
    [super requestFinished]; 
}

-(void)failWithError:(NSError *)theError{
    [kpRequest requestFinishedOnRequestThread]; 
    [super failWithError:theError]; 
}
@end

@interface ExtendedFormRequest : ASIFormDataRequest <ExtendedRequest>
{
    KPRequest* kpRequest;
}
@end

@implementation ExtendedFormRequest
- (void)setKPRequest:(KPRequest*)_request
{
    [kpRequest release];
    kpRequest = [_request retain];
}
- (void)requestFinished
{
    [kpRequest requestFinishedOnRequestThread]; 
    [super requestFinished]; 
}
@end

#pragma mark Utility functions

static NSString* uriEncode(NSString* str)
{
	return [(NSString*)CFURLCreateStringByAddingPercentEscapes(kCFAllocatorDefault, (CFStringRef)str, NULL, CFSTR(":/?#[]@!$&’()*+,;="), kCFStringEncodingUTF8) autorelease];
}

@protocol ArgBuilder
- (void)addArgument:(id)arg forKey:(NSString*)key;
@end

static void buildDict(id<ArgBuilder> builder, NSDictionary* body, NSString* prefix);

static void buildArr(id<ArgBuilder> builder, NSArray* arr, NSString* key)
{
	NSString* fullKey = [NSString stringWithFormat:@"%@[]", key];
	for (id o in arr)
	{
		if ([o isKindOfClass:[NSDictionary class]])
		{
			buildDict(builder, (NSDictionary*)o, fullKey);
		} 
		else if ([o isKindOfClass:[NSArray class]])
		{
			buildArr(builder, (NSArray*)o, fullKey);
		}
		else
		{
			[builder addArgument:o forKey:fullKey];
		}
	}
}

static void buildDict(id<ArgBuilder> builder, NSDictionary* body, NSString* prefix)
{
	for (NSString* k in [body allKeys])
	{
		id v = [body objectForKey:k];
		NSString* fullKey = prefix ? [NSString stringWithFormat:@"%@[%@]", prefix, k] : k;
		if ([v isKindOfClass:[NSDictionary class]])
		{
			buildDict(builder, (NSDictionary*)v, fullKey);
		} 
		else if ([v isKindOfClass:[NSArray class]])
		{
			buildArr(builder, (NSArray*)v, fullKey);
		}
		else
		{
			[builder addArgument:v forKey:fullKey];
		}
	}
}

static void buildRoot(id<ArgBuilder> builder, NSDictionary* body) {
	buildDict(builder, body, NULL);
}

@interface FormBuilder : NSObject<ArgBuilder>
{
	ASIFormDataRequest* request;
};
- (void)addArgument:(id)arg forKey:(NSString*)key;
+ (FormBuilder*)builderForRequest:(ASIFormDataRequest*)request;
@property (nonatomic, retain) ASIFormDataRequest* request;
@end
@implementation FormBuilder
@synthesize request;
- (void)addArgument:(id)arg forKey:(NSString*)key {
	[self.request addPostValue:arg forKey:key];
}
+ (FormBuilder*)builderForRequest:(ASIFormDataRequest*)request
{
	FormBuilder* rv = [[self new] autorelease];
	rv.request = request;
	return rv;
}

- (void)dealloc
{
    self.request = nil;
    [super dealloc];
}
@end

@interface QueryBuilder : NSObject<ArgBuilder>
{
	NSMutableString* accum;
};
- (void)addArgument:(id)arg forKey:(NSString*)key;
- (NSString*)queryString;
@end
@implementation QueryBuilder
- (void)addArgument:(id)arg forKey:(NSString*)key
{
	if (accum)
	{
		[accum appendFormat:@"&%@=%@", uriEncode(key), uriEncode(arg)];
	}
	else
	{
		accum = [NSMutableString stringWithFormat:@"%@=%@", uriEncode(key), uriEncode(arg)];
	}
}
- (NSString*)queryString
{
	return accum;
}	
@end

@implementation KPRequest

#pragma mark KPRequest properties

@synthesize requiresSignature;
@synthesize requiresUserSession;
@synthesize requiresDeviceSession;

@synthesize responseText = mResponseText;
@synthesize responseData = mResponseData;
@synthesize responseJSON = mResponseJSON;

@synthesize responseAsString = mResponseAsString;
@synthesize responseAsJson = mResponseAsJSON;
@synthesize responseAsData = mResponseAsData;

@synthesize path = mPath;

- (void)setRequest:(ASIHTTPRequest*)request
{
	// Cleanup existing
	mRequest.delegate = nil;
    [(ASIHTTPRequest<ExtendedRequest>*)mRequest setKPRequest:nil];
    [mRequest release];
	
	//setup new.    
	mRequest = [request retain];
	request.delegate = self;
    [(ASIHTTPRequest<ExtendedRequest>*)mRequest setKPRequest:self];
}

- (ASIHTTPRequest*)request
{
	return mRequest;
}

#pragma mark -
#pragma mark Life-Cycle
#pragma mark -

- (id)init
{
	self = [super init];
    if (self != nil)
    {
        requiresSignature = YES;
        requiresUserSession = YES;
        requiresDeviceSession = YES;
    }

	return self;
}

- (void)dealloc
{
    self.responseText = nil;
    self.responseJSON = nil;
    self.responseData = nil;

	self.responseAsString = nil;
	self.responseAsJson = nil;
	self.responseAsData = nil;

    self.path = nil;
	self.request = nil;
	
	[super dealloc];
}

#pragma mark -
#pragma mark Creation Methods
#pragma mark -

- (void)genRequestWithURL:(NSURL*)url andASIClass:(Class)asiHttpRequestSubclass
{
    ASIHTTPRequest* req = [[asiHttpRequestSubclass alloc] initWithURL:url];
	KPAssert([req conformsToProtocol:@protocol(ExtendedRequest)], @"%s doesn't conform to the ExtendedRequest protocol", object_getClassName(req));
	
	// setup our config
	req.timeOutSeconds = 20.f;
	req.numberOfTimesToRetryOnTimeout = 2;
	
	self.request = req;
    [req release];
}

- (void)genRequestWithPath:(NSString*)path andASIClass:(Class)asiHttpRequestSubclass
{    
	if ([path hasPrefix:@"/"])
	{
		path = [path substringFromIndex:1];
	}

	[self genRequestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@", 
                                                  [Kittypad getServerUrl]
                                                  , path]] andASIClass:(Class)asiHttpRequestSubclass];
}

+ (NSString*)embedQueryInPath:(NSString*)path andQuery:(NSDictionary*)query
{
	QueryBuilder* queryBuilder = [QueryBuilder new];
	buildRoot(queryBuilder, query);
	NSString* queryString = [queryBuilder queryString];
	[queryBuilder release];
	if (queryString) 
	{
		path = [NSString stringWithFormat:@"%@?%@", path, queryString];
	}
	return path;
}

+ (id)request
{
	return [[[self alloc] init] autorelease];
}

+ (id)requestWithPath:(NSString*)_path andASIClass:(Class)asiHttpRequestSubclass
{
	KPRequest* req = [self request];
    req.path = _path;
    [req genRequestWithPath:_path andASIClass:asiHttpRequestSubclass];
	return req;
}

+ (id)getRequestWithPath:(NSString*)path
{
	return [self requestWithPath:path andASIClass:[ExtendedGetRequest class]];
}

+ (id)getRequestWithPath:(NSString*)path andQuery:(NSDictionary*)query
{
	return [self getRequestWithPath:[self embedQueryInPath:path andQuery:query]];
}

+ (id)getRequestWithPath:(NSString*)path andQueryString:(NSString*)queryString
{
	return [self getRequestWithPath:[NSString stringWithFormat:@"%@?%@", path, queryString]];
}

+ (id)putRequestWithPath:(NSString*)path andBody:(NSDictionary*)body
{
	KPRequest* req = [self requestWithPath:path andASIClass:[ExtendedFormRequest class]];
    req.request.requestMethod = @"PUT";
	buildRoot([FormBuilder builderForRequest:(ASIFormDataRequest*)req->mRequest], body);
	return req;
}

+ (id)putRequestWithPath:(NSString*)path andBodyString:(NSString*)bodyString
{
	KPRequest* req = [self requestWithPath:path andASIClass:[ExtendedFormRequest class]];
    req.request.requestMethod = @"PUT";
	// quick hack
    [req.request addRequestHeader:@"Content-Type" value:@"application/x-www-form-urlencoded; charset=UTF-8"];
    req.request.postBody = [NSMutableData dataWithData:[bodyString dataUsingEncoding:NSUTF8StringEncoding]];
	return req;
}

+ (id)postRequestWithPath:(NSString*)path andBody:(NSDictionary*)body
{
	KPRequest* req = [self requestWithPath:path andASIClass:[ExtendedFormRequest class]];
    req.request.requestMethod = @"POST";
	buildRoot([FormBuilder builderForRequest:(ASIFormDataRequest*)req.request], body);
	return req;
}

+ (id)postRequestWithPath:(NSString*)path andBodyString:(NSString*)bodyString
{
	KPRequest* req = [self requestWithPath:path andASIClass:[ExtendedFormRequest class]];
    req.request.requestMethod = @"POST";
	// quick hack
    [req.request addRequestHeader:@"Content-Type" value:@"application/x-www-form-urlencoded; charset=UTF-8"];
    req.request.postBody = [NSMutableData dataWithData:[bodyString dataUsingEncoding:NSUTF8StringEncoding]];
	return req;
}

+ (id)deleteRequestWithPath:(NSString*)path
{
	KPRequest* req = [self requestWithPath:path andASIClass:[ExtendedGetRequest class]];
    req.request.requestMethod = @"DELETE";
	return req;
}

+ (id)deleteRequestWithPath:(NSString*)path andQuery:(NSDictionary*)query
{
	return [self deleteRequestWithPath:[self embedQueryInPath:path andQuery:query]];
	
}

// And here is the super deluxe generic deal.
+ (id)requestWithPath:(NSString *)path andMethod:(NSString*)method andArgs:(NSDictionary*)args
{
	if ([method isEqualToString:@"GET"])
		return [self getRequestWithPath:path andQuery:args];
	
	if ([method isEqualToString:@"POST"])
		return [self postRequestWithPath:path andBody:args];
	
	if ([method isEqualToString:@"PUT"])
		return [self putRequestWithPath:path andBody:args];
	
	if ([method isEqualToString:@"DELETE"])
		return [self deleteRequestWithPath:path];
	
	return nil;
}

+ (id)requestWithPath:(NSString *)path andMethod:(NSString*)method andArgString:(NSString*)args
{
	if ([method isEqualToString:@"GET"])
		return [self getRequestWithPath:path andQueryString:args];
	
	if ([method isEqualToString:@"POST"])
		return [self postRequestWithPath:path andBodyString:args];
	
	if ([method isEqualToString:@"PUT"])
		return [self putRequestWithPath:path andBodyString:args];
	
	if ([method isEqualToString:@"DELETE"])
		return [self deleteRequestWithPath:path];
	
	return nil;
}

#pragma mark -
#pragma mark Response Delegate Methods
#pragma mark -

// If you call this, you'll get notified when the request succeeds or fails,
// with the plain text of the body.  This returns self, so you can chain.
- (id)onRespondText:(id<KPResponseText>)responseBlock
{
	self.responseText = responseBlock;
    
	return self;
}

// If you call this, you'll get notified when the request succeeds or fails,
// with the plain data of the body.  This returns self, so you can chain.
- (id)onRespondData:(id<KPResponseData>)responseBlock;
{
	self.responseData = responseBlock;
	return self;
}

// If you call this, you'll get notified when the request succeeds or fails,
// with the body all JSON-parsed just for you.  This returns self, so you can chain.
- (id)onRespondJSON:(id<KPResponseJSON>)responseBlock;
{
	self.responseJSON = responseBlock;
	return self;
}

#pragma mark -
#pragma mark Signing
#pragma mark -

- (void)signWithKey:(NSString*)key secret:(NSString*)secret
{
    if (!isSigned && requiresSignature)
    {
        NSString* q = nil;
        
        if ([mRequest.requestMethod isEqualToString:@"GET"] || [mRequest.requestMethod isEqualToString:@"DELETE"])
        {
            q = [mRequest.url query];
        }
        else
        {
            [mRequest buildPostBody];
            NSData* postBody = [mRequest postBody];
            if (postBody)
            {
                q = [[[NSString alloc] initWithData:postBody encoding:NSUTF8StringEncoding] autorelease];
            }
        }

        if (nil == q) 
			q = @"";
        NSString* toSign = [NSString stringWithFormat:@"%@+%@+%@+%@", [mRequest.url path], secret, mRequest.requestMethod, q];
        NSString* signingKey = [NSString stringWithFormat:@"%@", secret];
        
        NSLog(@"To Sign:%@", toSign);
        
        // I'm cheating, we can remove this dependency later
        NSString* sig = [KPRequest HMAC_SHA1SignatureForText:toSign usingSecret:signingKey];
        NSLog(@"SigningKey:%@", signingKey);
        NSLog(@"Signiture:%@",sig);
		
		NSURL* oldUrl = mRequest.url;
		NSLog(@"old URL is %@", oldUrl);
		
		NSLog(@"new URL is %@", [NSString stringWithFormat:@"%@&signature=%@",oldUrl,sig]);
		
		mRequest.url = [NSURL URLWithString:[NSString stringWithFormat:@"%@&signature=%@",[oldUrl absoluteURL] ,sig] ];

        isSigned = YES;
    }
}

+ (NSString *)HMAC_SHA1SignatureForText:(NSString *)inText usingSecret:(NSString *)inSecret {
	NSData *secretData = [inSecret dataUsingEncoding:NSUTF8StringEncoding];
	NSData *textData = [inText dataUsingEncoding:NSUTF8StringEncoding];
	unsigned char result[20];
	hmac_sha1((unsigned char *)[textData bytes], [textData length], (unsigned char *)[secretData bytes], [secretData length], result);
	
	//Base64 Encoding
	char base64Result[32];
	size_t theResultLength = 32;
	Base64EncodeData(result, 20, base64Result, &theResultLength);
	NSData *theData = [NSData dataWithBytes:base64Result length:theResultLength];
	NSString *base64EncodedResult = [[[NSString alloc] initWithData:theData encoding:NSUTF8StringEncoding] autorelease];
	
	return base64EncodedResult;
}

#pragma mark -
#pragma mark Execution
#pragma mark -

// This generates and starts executing the request.  Make sure you set the success/failure blocks before
// calling this.
- (void)execute
{
	// sign it if we need to
	[self signWithKey:[Kittypad getKey]
             secret:[Kittypad getSecret]];
//    [self.request setDelegate:self];

    [self.request startAsynchronous];
}

- (void)retry
{
	self.request = [mRequest copy];
    [self execute];
}

#pragma mark -
#pragma mark Response Methods
#pragma mark -

// This is called on the request thread, before -requestFinished: is called.
- (void)requestFinishedOnRequestThread
{
	// If we have any of these callbacks, we're going to need the data in string format.
	if (mResponseText)
	{
		NSStringEncoding encoding = [mRequest responseEncoding];
		if (!encoding) encoding = NSUTF8StringEncoding;
		NSData* d = [mRequest responseData];
		mResponseAsString = [[NSString alloc] initWithBytes:[d bytes] length:[d length] encoding:encoding];
        NSLog(@"responseAsText %@", mResponseAsString);
		if (!mResponseAsString)
		{
			// @HACK we are being bitten by the fact that the server doesn't really know what the encoding is.
			// it's probably straight ASCII in the database.  We need to fix this server-side in the long run
			// and make sure the output encoding is correctly translating data coming out of the db.  For now
			// though, we can just use ASCII iff the response encoding fails.
			mResponseAsString = [[NSString alloc] initWithBytes:[d bytes] length:[d length] encoding:NSASCIIStringEncoding];
              NSLog(@"responseAsText %@", mResponseAsString);
		}
	}
	
	// same for json...
	if (mResponseJSON)
	{
		self.responseAsJson = [[CJSONDeserializer deserializer] deserializeAsDictionary:[mRequest responseData] error:nil];
		NSLog(@"responseAsJson %@ ", self.responseAsJson);
		
	}
	
	// same for data.
	if (mResponseData)
	{
		self.responseAsData = [mRequest responseData];
	}
}

// This relies on -requestFinishedOnRequestThread being called first.
- (void)requestFinished:(ASIHTTPRequest *)request
{
	[mResponseText onResponseText:mResponseAsString withResponseCode:mRequest.responseStatusCode];
	[mResponseData onResponseData:mResponseAsData withResponseCode:mRequest.responseStatusCode];
	[mResponseJSON onResponseJSON:mResponseAsJSON withResponseCode:mRequest.responseStatusCode];
	
	// we're done here
	self.request = nil;
}

- (void)requestFailed:(ASIHTTPRequest *)request
{
    [self requestFinished:request];
}

@end
