//
//  KittypadCPP.m
//  KittypadSDK
//
//  Created by de meng on 7/24/11.
//  Copyright 2011 Kittypad. All rights reserved.
//

#import "KittypadCPP.h"
#include "Kittypad.h"

void KittypadCPP::start() {
    [Kittypad start];
}

void KittypadCPP::postScore(int score) {
    [Kittypad postScore:score];
}

