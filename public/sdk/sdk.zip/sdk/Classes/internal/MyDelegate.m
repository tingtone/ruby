#import "MyDelegate.h"


@implementation MyDelegate

-(void)onClose:(NSString*)message
{
    UIAlertView *m = [[UIAlertView alloc]
                          initWithTitle: @"Time is up!"
                          message: @"The app will exit!"
                          delegate: self
                          cancelButtonTitle:@"OK"
                          otherButtonTitles:nil];
 
    [m show];  
    [m release];    
    
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
	exit(0);
}
@end
