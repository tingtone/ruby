

#import "KPPostScore.h"
#import "KPData.h"
#import "ASIFormDataRequest.h"
#import "Kittypad+internal.h"

static KPPostScore* _instance = nil;
@implementation KPPostScore
@synthesize postArgs;
+(KPPostScore*)instance{
    @synchronized(self)
    {
        if (!_instance)
            _instance= [[self alloc] init];
    }
    [_instance.postArgs removeAllObjects];
    return _instance;
}

-(id)init {
	self = [super init];
	if (self != nil) {
        postArgs = [[NSMutableDictionary alloc] init];
	}
	return self;
}

//post form device_identifier=abcd-efgh-ijkl&score=100&category_id=5
///api/v1/score_trakcers.json
-(void)post_score:(int)score {
    NSLog(@"start post score!");
    
    if ([[KPData instance] getKPValue:kEmail] == nil) {
        return;
    }
    
    //post form device_identifier=abcd-efgh-ijkl&time=60&time_to_pause=1&time_to_break=2
    
    NSMutableDictionary* pendingData = [NSMutableDictionary dictionaryWithCapacity:20];
    
    //device id;
    NSString *udid = [[UIDevice currentDevice] uniqueIdentifier];
    [pendingData setObject:udid forKey:@"device_identifier"];
    [pendingData setObject:[Kittypad getKey] forKey:@"key"];
    [pendingData setObject:[NSNumber numberWithInt:score] forKey:@"score"];
    
    NSTimeInterval interval = [[NSDate date] timeIntervalSince1970]; 
    NSString *dateStr = [NSString stringWithFormat:@"%.0f", interval];
    [pendingData setObject:dateStr forKey:kLastUpdate];
    
    NSString* path = @"api/v1/score_trackers.json";
    NSMutableString *urlBuf = [[NSMutableString alloc]init];
    [urlBuf appendString:[Kittypad getServerUrl]];
    [urlBuf appendString:path];
    NSURL* url =[NSURL URLWithString:urlBuf];
    NSString* secret = [Kittypad getSecret];
    ASIFormDataRequest  *request = [[[ASIFormDataRequest alloc] initWithURL:url] autorelease];
    request = [[KPData instance] addRequestWithDitionary:request withDictionary:pendingData];
    NSString* sig = [[[KPData instance] getSignitureWithPath:@"/api/v1/score_trackers.json" secret:secret method:@"POST" query:pendingData]retain];
    
    [request addPostValue:sig forKey:@"signature"];
    [request setDelegate:self];
    [request startSynchronous];
    [urlBuf release];
}


- (void)requestFailed:(ASIHTTPRequest *)request
{
    NSLog(@"requestFailed");
    NSError *error = [request error];
    NSLog(@"%@",[error description]);
}

- (void)requestFinished:(ASIHTTPRequest *)request
{
    // Use when fetching text data
    NSLog(@"requestFinished");
    NSString *responseString = [request responseString];
    NSLog(@"%@", responseString);
}
@end
