//
//  SharedUtil.h
//  MathNijia
//
//  Created by julian on 4/15/11.
//  Copyright 2011 kittypad. All rights reserved.
//

#ifndef UTIL_KITTYDUTIL_H_
#define UTIL_KITTYDUTIL_H_

class KittyUtil {
public:
    static NSString* getLocalizedString(NSString* key, NSString* val);
};


#endif /* UTIL_KITTYDUTIL_H_ */
