//
//  KPPostScore.h
//  KittypadSDK
//
//  Created by Chang Cheng on 7/12/11.
//  Copyright 2011 ChangCheng. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface KPPostScore : NSObject {
    
}
@property(nonatomic, retain) IBOutlet NSMutableDictionary * postArgs;
+(KPPostScore*)instance;
-(void)post_score:(int)score;
@end
