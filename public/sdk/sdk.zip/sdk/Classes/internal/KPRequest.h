
#import <Foundation/Foundation.h>

@class ASIHTTPRequest, KPRequest;

@protocol KPResponseText <NSObject>
- (void)onResponseText:(NSString*)body withResponseCode:(unsigned int)responseCode;
@end

@protocol KPResponseData <NSObject>
- (void)onResponseData:(NSData*)body withResponseCode:(unsigned int)responseCode;
@end

@protocol KPResponseJSON <NSObject>
- (void)onResponseJSON:(id)body withResponseCode:(unsigned int)responseCode;
@end

@protocol ExtendedRequest
- (void)setKPRequest:(KPRequest*)_request;
@end

@interface KPRequest : NSObject {
	id<KPResponseText> mResponseText;
	id<KPResponseData> mResponseData;
	id<KPResponseJSON> mResponseJSON;
	ASIHTTPRequest* mRequest;
	NSString* mResponseAsString;
	NSObject* mResponseAsJSON;
	NSData* mResponseAsData;

	NSString* mPath;
	
    BOOL isSigned;
    
    BOOL requiresSignature;
}

// Here's the basic deal.
+ (id)requestWithPath:(NSString*)path andASIClass:(Class)asiHttpRequestSubclass;

// Here are specific deals.
+ (id)getRequestWithPath:(NSString*)path;
+ (id)getRequestWithPath:(NSString*)path andQuery:(NSDictionary*)query;
+ (id)getRequestWithPath:(NSString*)path andQueryString:(NSString*)queryString;
+ (id)putRequestWithPath:(NSString*)path andBody:(NSDictionary*)body;
+ (id)putRequestWithPath:(NSString*)path andBodyString:(NSString*)bodyString;
+ (id)postRequestWithPath:(NSString*)path andBody:(NSDictionary*)body;
+ (id)postRequestWithPath:(NSString*)path andBodyString:(NSString*)bodyString;
+ (id)deleteRequestWithPath:(NSString*)path;
+ (id)deleteRequestWithPath:(NSString*)path andQuery:(NSDictionary*)query;

+ (NSString *)HMAC_SHA1SignatureForText:(NSString *)inText usingSecret:(NSString *)inSecret;

// And here is the super deluxe generic deal.
+ (id)requestWithPath:(NSString *)path andMethod:(NSString*)method andArgs:(NSDictionary*)args;
+ (id)requestWithPath:(NSString *)path andMethod:(NSString*)method andArgString:(NSString*)args;

// If you call this, you'll get notified when the request succeeds or fails,
// with the plain text of the body.  This returns self, so you can chain.
- (id)onRespondText:(id<KPResponseText>)responseBlock;

// If you call this, you'll get notified when the request succeeds or fails,
// with the plain data of the body.  This returns self, so you can chain.
- (id)onRespondData:(id<KPResponseData>)responseBlock;

// If you call this, you'll get notified when the request succeeds or fails,
// with the body all JSON-parsed just for you.  This returns self, so you can chain.
- (id)onRespondJSON:(id<KPResponseJSON>)responseBlock;

// This starts executing the request.  Make sure you set the success/failure blocks before
// calling this.
- (void)execute;

// Signs this request (if desired and not already done) with the given key/secret.
- (void)signWithKey:(NSString*)key secret:(NSString*)secret;

@property (nonatomic, assign) BOOL requiresSignature;
@property (nonatomic, assign) BOOL requiresDeviceSession;
@property (nonatomic, assign) BOOL requiresUserSession;

@property (nonatomic, retain, readonly) ASIHTTPRequest* request;

@end
