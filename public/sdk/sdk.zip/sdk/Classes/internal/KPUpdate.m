//
//  KPUpdate.m
//  KittypadSDK
//
//  Created by Chang Cheng on 7/11/11.
//  Copyright 2011 ChangCheng. All rights reserved.
//

#import "KPUpdate.h"
#import "ASIHTTPRequest.h"
#import "KPData.h"
#import "CJSONDeserializer.h"
#import "Kittypad+internal.h"

static KPUpdate* _instance = nil;
@implementation KPUpdate
@synthesize postArgs;
+(KPUpdate*)instance{
    @synchronized(self)
    {
        if (!_instance)
            _instance= [[self alloc] init];
    }
    [_instance.postArgs removeAllObjects];
    return _instance;
}

-(id)init {
	self = [super init];
	if (self != nil) {
        postArgs = [[NSMutableDictionary alloc] init];
	}
	return self;
}

-(void)update{
    NSString *udid = [[UIDevice currentDevice] uniqueIdentifier];
    NSTimeInterval interval = [[NSDate date] timeIntervalSince1970]; 
    NSString* dateStr = [NSString stringWithFormat:@"%.0f", interval];
    [postArgs setObject:dateStr forKey:kLastUpdate];
    [postArgs setObject:udid forKey:@"device_identifier"];
    NSString* key = [Kittypad getKey];
    [postArgs setObject:key forKey:@"key"];
    NSString* secret = [Kittypad getSecret];   
    NSString* sig = [[[KPData instance] getSignitureWithPath:@"/api/v1/owners/sync.json" secret:secret method:@"GET" query:postArgs]retain];

    [postArgs setObject:sig forKey:@"signature"];
    
    NSMutableString *urlBuf = [[NSMutableString alloc]init];
    [urlBuf appendString:[Kittypad getServerUrl]];
    [urlBuf appendString:@"api/v1/owners/sync.json"];
    NSArray *keyArray =  [postArgs allKeys];
    int count = [keyArray count];
    for (int i=0; i < count; i++) {
        if(i==0){
            [urlBuf appendFormat:@"?%@=%@",[keyArray objectAtIndex:i],[postArgs objectForKey:[ keyArray objectAtIndex:i]]];
        }else{
            [urlBuf appendFormat:@"&%@=%@",[keyArray objectAtIndex:i],[postArgs objectForKey:[ keyArray objectAtIndex:i]]];
        }
    }

    NSURL* url =[NSURL URLWithString:urlBuf];
    NSLog(@"Get Request is:%@", urlBuf);
    ASIHTTPRequest *request = [[[ASIHTTPRequest alloc] initWithURL:url] autorelease];
    [request setDelegate:self];
    [request startSynchronous];
    [urlBuf release];
    
}


- (void)requestFailed:(ASIHTTPRequest *)request
{
    NSLog(@"requestFailed");
    NSError *error = [request error];
    NSLog(@"%@",[error description]);
    
}

- (void)requestFinished:(ASIHTTPRequest *)request
{
    // Use when fetching text data
    NSLog(@"requestFinished");
    NSString *responseString = [request responseString];
    NSLog(@"%@", responseString);
    
    NSError *parse_error = nil;
    NSData* data = [responseString dataUsingEncoding:NSUTF8StringEncoding];
    NSDictionary* root = [[CJSONDeserializer deserializer] deserializeAsDictionary:data error:&parse_error];
    
    if(request.responseStatusCode == 200){
        if(root!=nil){
            BOOL error = [[root objectForKey:@"error"] boolValue];
            if (error ==NO) {
                NSLog(@"no error:)");
                NSDictionary* owner = [root objectForKey:@"owner"] ;
                [[KPData instance] setKPValue:[owner objectForKey:@"name"] withKey:kOwnerName];
                [[KPData instance] setKPValue:[owner objectForKey:@"email"] withKey:kEmail];
                
                NSDictionary* player = [root objectForKey:@"player"] ;
                [[KPData instance] setKPValue:[player objectForKey:@"language"]withKey:kLanguage];
                [[KPData instance] setKPValue:[player objectForKey:@"name"] withKey:kPlayerName];
                [[KPData instance] setKPValue:[player objectForKey:@"gender"] withKey:kPlayerGender];
                
                NSDate *birthday = [NSDate dateWithTimeIntervalSince1970:[[player objectForKey:@"birthday"]doubleValue]];
                [[KPData instance] setKPValue:birthday withKey:kPlayerBirthday];
                
                [[KPData instance] setKPValue:[player objectForKey:@"time_between_pause"] withKey:kInteval_pause];
                [[KPData instance] setKPValue:[player objectForKey:@"time_between_breaks"] withKey:kInteval_break];
                    
                [[KPData instance] setKPValue:[player objectForKey:@"break_duration"] withKey:kBreak_duration];
                [[KPData instance] setKPValue:[player objectForKey:@"pause_duration"] withKey:kPause_duration];


                [[KPData instance] setKPValue:[player objectForKey:@"time_to_break"]withKey:kInteval_break_left];
                [[KPData instance] setKPValue:[player objectForKey:@"time_to_pause"]withKey:kInteval_pause_left];
                
                [[KPData instance] setKPValue:[player objectForKey:@"weekday_time"] withKey:kWeekday_time];
                [[KPData instance] setKPValue:[player objectForKey:@"weekend_time"] withKey:kWeekend_time];
                
                NSLog(@"sync time_left = %@", [player objectForKey:@"time_left"]);
                
                NSInteger weekday = [Kittypad getWeekday];
                // sat or sun
                if (weekday == 7 || weekday == 1) {
                    [[KPData instance] setKPValue:[player objectForKey:@"time_left"] withKey:kWeekend_time_left];
                }
                else {
                    [[KPData instance] setKPValue:[player objectForKey:@"time_left"] withKey:kWeekday_time_left];
                }
                
                NSDate* now = [NSDate date];
                [[KPData instance] setKPValue:now withKey:kLastUpdate];                
    
//                UIAlertView *message = [[UIAlertView alloc] initWithTitle:[NSString stringWithFormat:@"Sync success from %@ to server"]  
//                                                                  message:@"Yeah!"  
//                                                  
//                                                        cancelButtonTitle:@"OK"  
//                                                        otherButtonTitles:nil];  
//                [message show];  
//                [message release]; 
            } else
            {
                NSLog(@"error == ture ><");
            }
        }
    }
}

@end
