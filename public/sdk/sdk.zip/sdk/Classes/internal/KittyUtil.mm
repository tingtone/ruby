//
//  SharedUtil.m
//  MathNijia
//
//  Created by julian on 4/15/11.
//  Copyright 2011 kittypad. All rights reserved.
//
#import "KittyUtil.h"
#import "Kittypad+internal.h"

NSString* KittyUtil::getLocalizedString(NSString* key, NSString* val) {
    return NSLocalizedStringWithDefaultValue(key, nil, [Kittypad getResourceBundle], val, nil);
}
