//
//  KPUpdate.h
//  KittypadSDK
//
//  Created by Chang Cheng on 7/11/11.
//  Copyright 2011 ChangCheng. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface KPUpdate : NSObject {
      NSMutableDictionary * postArgs;
}
@property(nonatomic, retain) IBOutlet NSMutableDictionary * postArgs;
+(KPUpdate*)instance;

-(void)update;

@end
