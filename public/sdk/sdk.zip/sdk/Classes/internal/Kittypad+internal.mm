//
//  MyClass.m
//  MathNinja
//
//  Created by julian on 5/8/11.
//  Copyright 2011 kittypad. All rights reserved.
//

#import "Kittypad+internal.h"
#import "KControllerLoader.h"
#import "TimeMgr.h"

#import "SettingController.h"
#import "ChangeLinksController.h"
#import "IntroduceController.h"

#import "KPData.h"
#import "PauseController.h"
#import "MyDelegate.h"
#import "KPUpdate.h"

static NSString* productKey_;
static NSString* productSecret_;
static NSString* server_;
static id<KittypadDelegate> delegate_;
static id<KittypadBreakDelegate> breakDelegate_;

static UITabBarController* tabController_;

//static UIInterfaceOrientation mPreviousOrientation;
static UIInterfaceOrientation mDashboardOrientation;
static KRootController* mRootController = nil;

static BOOL isChangeSettingButtonPress = FALSE;

@interface Kittypad (privateInternalInterface)
+(BOOL) talkToServerBefore;
+(void) talkToServer;
@end

@implementation Kittypad(internal)

+ (void) initializeProductKey:(NSString*)productKey 
						andSecret:(NSString*)productSecret 
                    serverUrl:(NSString*)server
                      andDelegate:(id<KittypadDelegate>)delegate;
{
    [productKey retain];
    [productKey_ release];
    productKey_ = productKey;
    
    [productSecret retain];
    [productSecret_ release];
    productSecret_ = productSecret;

    [server_ release];
    [server retain];
    server_ = server;
        
    [delegate retain];
    [delegate_ release];
    
    if (delegate == nil) {
        delegate_ = [[MyDelegate alloc]init];
    }
    else {
        delegate_ = delegate;
    }
    
    [[KPUpdate instance]update];
    
    [[TimeMgr instance]startTimer]; 
    
    if ([[KPData instance] getKPValue:kEmail] == nil) {
        [Kittypad start];
    }
}


+ (NSString*) getKey {
    NSLog(@" productKey_ %@",productKey_ );
    return productKey_;
}
+ (NSString*) getSecret {
    NSLog(@" productSecret_ %@",productSecret_ );
    return productSecret_;
}

+ (id<KittypadDelegate>) getDelegate{
    return delegate_;
}

+ (NSString*) getServerUrl {
    return server_; 
}

+ (NSBundle*)getResourceBundle
{
    NSString *bundlePath = [[NSBundle mainBundle] pathForResource:@"kittypadresource" ofType:@"bundle"];
    return [NSBundle bundleWithPath:bundlePath];
}



+(void)tryCreateDashboard
{
    if (!mRootController) {
        mRootController = [[[KControllerLoader loader] load:@"RootController"] retain];
    }
    [Kittypad transformViewToDashboardOrientation:mRootController.view];
   
    [mRootController viewWillAppear:YES];
	[[[UIApplication sharedApplication]  keyWindow]addSubview:mRootController.view];
    [mRootController viewDidAppear:YES];
    
}

+ (void) pushController:(UIViewController*) controller
{
    UIViewController* topController = mRootController.contentController;
    if ([topController isKindOfClass:[UINavigationController class]]) {
        UINavigationController* nagvController = (UINavigationController*)topController;
        [nagvController pushViewController:controller animated:YES];
    }
}

+ (void) popController
{
    UIViewController* topController = mRootController.contentController;
    if ([topController isKindOfClass:[UINavigationController class]]) {
        UINavigationController* nagvController = (UINavigationController*)topController;
        [nagvController popViewControllerAnimated: YES];
    }
}

+ (void) showController:(UIViewController*) child {
    [Kittypad tryCreateDashboard];
    
//    CGRect dashboardBounds = [Kittypad getDashboardBounds];
    CGRect modalRect = child.view.frame;
//	modalRect.origin.x = 0.5f * (dashboardBounds.size.width - modalRect.size.width);
	child.view.frame = modalRect;
    
    mRootController.transitionIn = kCATransitionFromTop;
	mRootController.transitionOut = kCATransitionFromBottom;
    
    [mRootController showController:child];
}


+(void)presentDashboard
{
    if (!isChangeSettingButtonPress) {
        if([[Kittypad getBreakDelegate] respondsToSelector:@selector(onPause)]) {
            [[Kittypad getBreakDelegate]onPause];
        }
    }

    SettingController* settingController;
    ChangeLinksController* changeLinksController;
    IntroduceController* introduceController;
    
    UIInterfaceOrientation orientation = [[UIApplication sharedApplication] statusBarOrientation];
    
    if (isPad) {
        if(orientation == UIInterfaceOrientationPortrait || 
           orientation == UIInterfaceOrientationPortraitUpsideDown) {
            settingController = [[[SettingController alloc] initWithNibName:@"SettingController-iPad" bundle:[Kittypad getResourceBundle]] autorelease];
            changeLinksController = [[[ChangeLinksController alloc] initWithNibName:@"ChangeLinksController-iPad" bundle:[Kittypad getResourceBundle]] autorelease];
            introduceController = [[[IntroduceController alloc] initWithNibName:@"IntroduceController-iPad" bundle:[Kittypad getResourceBundle]] autorelease];
        }
        else
        {
            settingController = [[[SettingController alloc] initWithNibName:@"SettingController-Landcape-iPad" bundle:[Kittypad getResourceBundle]] autorelease];
            changeLinksController = [[[ChangeLinksController alloc] initWithNibName:@"ChangeLinksController-Landcape-iPad" bundle:[Kittypad getResourceBundle]] autorelease];
            introduceController = [[[IntroduceController alloc] initWithNibName:@"IntroduceController-Landcape-ipad" bundle:[Kittypad getResourceBundle]] autorelease];
        }
    }
    else {
        if(orientation == UIInterfaceOrientationPortrait || 
           orientation == UIInterfaceOrientationPortraitUpsideDown) {
            settingController = [[[SettingController alloc] initWithNibName:@"SettingController" bundle:[Kittypad getResourceBundle]] autorelease];
            changeLinksController = [[[ChangeLinksController alloc] initWithNibName:@"ChangeLinksController" bundle:[Kittypad getResourceBundle]] autorelease];
            introduceController = [[[IntroduceController alloc] initWithNibName:@"IntroduceController" bundle:[Kittypad getResourceBundle]] autorelease];
        }
        else
        {
            settingController = [[[SettingController alloc] initWithNibName:@"SettingController-Landcape" bundle:[Kittypad getResourceBundle]] autorelease];
            changeLinksController = [[[ChangeLinksController alloc] initWithNibName:@"ChangeLinksController-Landcape" bundle:[Kittypad getResourceBundle]] autorelease];
            introduceController = [[[IntroduceController alloc] initWithNibName:@"IntroduceController-Landcape" bundle:[Kittypad getResourceBundle]] autorelease];
        }
    }
    
    tabController_ = [[UITabBarController alloc] init];
    NSArray* controllers = [NSArray arrayWithObjects:settingController,
                            changeLinksController,
                            introduceController, nil];
    [tabController_ setViewControllers:controllers];
    [tabController_ setSelectedIndex:2];
    [Kittypad showController:tabController_];
}

+ (UITabBarController*) getTabController
{
    return tabController_;
}



+(void)showPause:(int)viewType
{
    isChangeSettingButtonPress = TRUE;
    
    //type 1:pause 2:break
    PauseController *pauseController = [[[PauseController alloc] initWithNibName:@"PauseController" bundle:[Kittypad getResourceBundle]] autorelease];
    pauseController.type = viewType;

    CGRect bounds = [[UIScreen mainScreen] bounds];
    if (isPad) {
        [[pauseController view] setFrame:CGRectMake(120, bounds.size.height/2-256, 512, 512)];
    }
    else {
        [[pauseController view] setFrame:CGRectMake(60, bounds.size.height/2-100, 200, 200)];
    }
    
    CGAffineTransform newTransform = CGAffineTransformIdentity;
    UIInterfaceOrientation orientation = [[UIApplication sharedApplication] statusBarOrientation];

    if(orientation == UIInterfaceOrientationPortrait) {
        CGAffineTransformMake(1, 0, 0, -1, 0, 0);
    }
    else if(orientation == UIInterfaceOrientationPortraitUpsideDown) {
        CGAffineTransformMake(-1, 0, 0, 1, 0, 0);
    }
    else if(orientation == UIInterfaceOrientationLandscapeLeft){
        newTransform = CGAffineTransformMake(0, -1, 1, 0, 0, 0);
    }
    else if(orientation == UIInterfaceOrientationLandscapeRight){
        newTransform = CGAffineTransformMake(0, 1, -1, 0, 0, 0);
    }
    
    [pauseController.view setTransform:newTransform];
    
    [[[UIApplication sharedApplication]  keyWindow]addSubview:pauseController.view];
    
    CATransition* animation = [CATransition animation];
    animation.type = kCATransitionMoveIn;
    animation.subtype = kCATransitionFromLeft;
    animation.duration = 2.f;
    animation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    animation.delegate = self;
    [[[pauseController view] layer] addAnimation:animation forKey:nil];
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:2.f];
    [UIView commitAnimations];
    
    int inteval = 10; //just default.
    if(viewType==1)//pause
    {
        inteval = [[[KPData instance]getKPValue:kPause_duration]intValue];
    }else if(viewType==2){
        inteval = [[[KPData instance] getKPValue:kBreak_duration]intValue];
    }
    
    [NSTimer scheduledTimerWithTimeInterval:inteval target:self selector:@selector(removeView:) userInfo:pauseController repeats:NO]; 
}

+ (void)removeView:(NSTimer*)timer
{
    
    // maybe also fade out? for the eye-protect view.
    id controller = [timer userInfo];
    [controller stopMusic];
    isChangeSettingButtonPress = FALSE;
    [[controller view] removeFromSuperview ];
}

// TODO: if not added should not run
+(void)dismissDashboard
{
    if (mRootController) {
        [mRootController viewWillDisappear:YES];
        [mRootController.view removeFromSuperview];
        [mRootController viewDidAppear:YES];
    }
    if([[Kittypad getBreakDelegate] respondsToSelector:@selector(onResume)]) {
        [[Kittypad getBreakDelegate]onResume];
    }
    
    [[TimeMgr instance]startTimer];
}

+ (void)transformViewToDashboardOrientation:(UIView*)view
{
	UIInterfaceOrientation dashboardOrientation = mDashboardOrientation;
	[Kittypad transformView:view toOrientation:dashboardOrientation];
}

+ (void)transformView:(UIView*)view toOrientation:(UIInterfaceOrientation)orientation
{
	CGAffineTransform newTransform = CGAffineTransformIdentity;
	CGRect bounds = [[UIScreen mainScreen] bounds];
	CGPoint center = CGPointMake(CGRectGetMidX(bounds), CGRectGetMidY(bounds));
	switch (orientation) 
	{
		case UIInterfaceOrientationLandscapeRight:
			newTransform = CGAffineTransformMake(0, 1, -1, 0, 0, 0);
			bounds = CGRectMake(0.f, 0.f, bounds.size.height, bounds.size.width);
			break;
		case UIInterfaceOrientationLandscapeLeft:
			newTransform = CGAffineTransformMake(0, -1, 1, 0, 0, 0);
			bounds = CGRectMake(0.f, 0.f, bounds.size.height, bounds.size.width);
			break;
		case UIInterfaceOrientationPortraitUpsideDown:
			newTransform = CGAffineTransformMake(-1, 0, 0, -1, 0, 0);
			break;
		case UIInterfaceOrientationPortrait:
			newTransform = CGAffineTransformTranslate(newTransform, 0, 0);
			break;
		default:
			//OFAssert(NO, @"invalid orientation used");
			break;
	}
	
	[view setTransform:newTransform];
	view.bounds = bounds;
	view.center = center;
}


+ (CGRect)getDashboardBounds
{
    CGRect dashboardBounds = CGRectMake(3.f, 3.f, 1024.f, 748.f);
    
	return dashboardBounds;
}

+ (void) setDashboardOrientationInternal:(UIInterfaceOrientation)orientation
{    
    if (orientation != mDashboardOrientation)
	{
        mDashboardOrientation = orientation;
        
        if (mRootController) {
            [Kittypad transformView:mRootController.view toOrientation:orientation];
        }
    }
}

+ (UIInterfaceOrientation)getDashboardOrientationInternal
{
    return mDashboardOrientation;
}

+ (void) generateKittypadButtonInternalX:(float) x Y:(float)y
{
    UIButton *kittypadButton = [[UIButton alloc] initWithFrame:CGRectMake(x, y, 200.f, 50.0f)];
    CGAffineTransform newTransform = CGAffineTransformIdentity;
    newTransform = CGAffineTransformMake(0, -1, 1, 0, 0, 0);
    [kittypadButton setTransform:newTransform];
    UIImage *image=[UIImage imageNamed:@"trabsparency_1.png"];
    [kittypadButton setImage:image forState:UIControlStateNormal];
    
    [kittypadButton addTarget:self action:@selector(clickKittypadButton:) forControlEvents:UIControlEventTouchUpInside];
    
    [[[UIApplication sharedApplication]  keyWindow]addSubview:kittypadButton];
}

+ (void) clickKittypadButton: (id) sender
{
    [Kittypad start];
}

+(NSInteger) getWeekday {
    NSDate *date = [NSDate date];
    NSCalendar *calendar = [NSCalendar currentCalendar];
    NSDateComponents *comps;
    comps = [calendar components:(NSWeekCalendarUnit | NSWeekdayCalendarUnit | NSWeekdayOrdinalCalendarUnit)
                        fromDate:date];
    return [comps weekday];
}

+ (void) setBreakDelegateInternal:(id<KittypadBreakDelegate>)delegate {
    [delegate retain];
    [breakDelegate_ release];
    breakDelegate_ = delegate;
}

+ (id<KittypadBreakDelegate>) getBreakDelegate {
    return breakDelegate_;
}

@end
