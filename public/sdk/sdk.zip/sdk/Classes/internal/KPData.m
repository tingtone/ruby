#import "KPData.h"
#import "hmac.h"
#import "Base64Transcoder.h"
#import "ASIFormDataRequest.h"


@implementation KPData
static KPData* _instance = nil;
@synthesize myKeys;
NSString *const kLastUpdate = @"timestamp";
NSString *const kOwnerName = @"owner[name]";
NSString *const kEmail = @"owner[email]";
NSString *const kPassword = @"owner[password]";
NSString *const kDeviceID = @"player[device_identifier]";
NSString *const kAgent = @"player[device_user_agent]";
NSString *const kLanguage=@"player[language]";
NSString *const kPlayerName = @"player[name]";
NSString *const kPlayerGender = @"player[gender]";
NSString *const kPlayerBirthday = @"player[birthday]";
NSString *const kWeekday_time = @"player[weekday_time]";
NSString *const kWeekend_time = @"player[weekend_time]";
NSString *const kWeekday_time_left = @"player[weekday_time_left]";
NSString *const kWeekend_time_left = @"player[weekend_time_left]";
NSString *const kInteval_pause = @"player[time_between_pause]";
NSString *const kInteval_break = @"player[time_between_breaks]";
NSString *const kPause_duration = @"player[pause_duration]";
NSString *const kBreak_duration = @"player[break_duration]";
NSString *const kInteval_pause_left = @"player[time_to_pause]";
NSString *const kInteval_break_left = @"player[time_to_break]";

+(KPData*)instance{
    @synchronized(self)
    {
        if (!_instance)
            _instance= [[self alloc] init];
    }
    return _instance;
}

-(id)init {
	self = [super init];
	if (self != nil) {
        myKeys = [[NSMutableArray alloc] init];
        [myKeys addObject:kLastUpdate];
        [myKeys addObject:kOwnerName];
        [myKeys addObject:kEmail];
        [myKeys addObject:kPassword];
        [myKeys addObject:kDeviceID];
        [myKeys addObject:kAgent];
        [myKeys addObject:kLanguage];
        [myKeys addObject:kPlayerName];
        [myKeys addObject:kPlayerGender];
        [myKeys addObject:kPlayerBirthday];
        [myKeys addObject:kWeekday_time];
        [myKeys addObject:kWeekend_time];
        [myKeys addObject:kWeekday_time_left];
        [myKeys addObject:kWeekend_time_left];
        [myKeys addObject:kInteval_pause];
        [myKeys addObject:kInteval_break];
        [myKeys addObject:kPause_duration];
        [myKeys addObject:kBreak_duration];
        [myKeys addObject:kInteval_pause_left];
        [myKeys addObject:kInteval_break_left];
	}
	return self;
}

-(id) getKPValue:(NSString*) key
{
    return [[NSUserDefaults standardUserDefaults] objectForKey:key];
}

-(void) setKPValue:(id)value withKey:(NSString*)key
{
    if(value==NULL){
        NSLog(@"%@ --> value is null, not save", key);
        return ;
    }
	[[NSUserDefaults standardUserDefaults] setObject:value forKey:key];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

-(void)setKPValueWithDictonary:(NSDictionary*)dictionary{
    NSArray *keyArray =  [dictionary allKeys];
    int count = [keyArray count];
    for (int i=0; i < count; i++) {
        if([dictionary objectForKey:[ keyArray objectAtIndex:i]]==NULL){
            NSLog(@"%@ --> value is null, not save", [keyArray objectAtIndex:i]);
            continue;
        }
        [[NSUserDefaults standardUserDefaults] setObject:[dictionary objectForKey:[ keyArray objectAtIndex:i]] forKey:[keyArray objectAtIndex:i]];
    }
    [[NSUserDefaults standardUserDefaults] synchronize];
}

- (NSString *)HMAC_SHA1SignatureForText:(NSString *)inText usingSecret:(NSString *)inSecret {
	NSData *secretData = [inSecret dataUsingEncoding:NSUTF8StringEncoding];
	NSData *textData = [inText dataUsingEncoding:NSUTF8StringEncoding];
	unsigned char result[20];
	kittypad_hmac_sha1((unsigned char *)[textData bytes], [textData length], (unsigned char *)[secretData bytes], [secretData length], result);
	
	//Base64 Encoding
	char base64Result[32];
	size_t theResultLength = 32;
	Base64EncodeData(result, 20, base64Result, &theResultLength);
	NSData *theData = [NSData dataWithBytes:base64Result length:theResultLength];
	NSString *base64EncodedResult = [[[NSString alloc] initWithData:theData encoding:NSUTF8StringEncoding] autorelease];
	
	return base64EncodedResult;
}

- (NSString*)getSignitureWithPath:(NSString*)path secret:(NSString*)secret method:(NSString*)method query:(NSDictionary*)data
{
    NSArray *keys = [data allKeys];
    NSString* query =@"";
    int i=0;
    for (NSString *key in keys) {
        if(i==0){
            NSLog(@"%@ is %@",key, [data objectForKey:key]);
            query = [query stringByAppendingFormat:@"%@=%@",key,[data objectForKey:key]];
        } else{
            NSLog(@"%@ is %@",key, [data objectForKey:key]);
            query = [query stringByAppendingFormat:@"&%@=%@",key,[data objectForKey:key]];
        }
        i++;
	}
    NSString* toSign = [NSString stringWithFormat:@"%@+%@+%@+%@", path, secret, method, query];
    NSLog(@"client before sign:%@", toSign);
    NSString* sig = [self HMAC_SHA1SignatureForText:toSign usingSecret:secret];
    NSLog(@"client Signiture:%@",sig);
    return sig;
}

-(ASIFormDataRequest*)addRequestWithDitionary:(ASIFormDataRequest*)request withDictionary:(NSDictionary*)data{
    NSArray *keyArray =  [data allKeys];
    int count = [keyArray count];
    for (int i=0; i < count; i++) {
        [request addPostValue:[data objectForKey:[ keyArray objectAtIndex:i]] forKey:[keyArray objectAtIndex:i]];  
        NSLog(@"%@ is %@",[ keyArray objectAtIndex:i], [data objectForKey:[ keyArray objectAtIndex:i]]);
    }
    return request;
}

-(void)KPDataDebug{
    int count = [myKeys count];
    NSLog(@"--------debug--begin-------------------");
    for (int i=0; i < count; i++) {
        NSLog(@"%@ --> %@ ", [myKeys objectAtIndex:i], [[NSUserDefaults standardUserDefaults]objectForKey:[myKeys objectAtIndex:i]]);
    }
    NSLog(@"-------debug--end--------------------");

}
@end
