#import <Foundation/Foundation.h>
@class ASIFormDataRequest;

@interface KPData : NSObject {    
    NSMutableArray* myKeys;
}
@property(retain,nonatomic)  NSMutableArray* myKeys;


extern NSString *const kLastUpdate;

extern NSString *const kOwnerName;
extern NSString *const kEmail;
extern NSString *const kPassword;
extern NSString *const kDeviceID;
extern NSString *const kAgent;
extern NSString *const kLanguage;
extern NSString *const kPlayerName;
extern NSString *const kPlayerGender;
extern NSString *const kPlayerBirthday;

//the naming convention is xxx and xxx_left
//means define and variable 

extern NSString *const kWeekday_time_left;
extern NSString *const kWeekend_time_left;
extern NSString *const kWeekday_time;
extern NSString *const kWeekend_time;

extern NSString *const kInteval_pause;
extern NSString *const kInteval_break;
extern NSString *const kInteval_pause_left;
extern NSString *const kInteval_break_left;

extern NSString *const kPause_duration;
extern NSString *const kBreak_duration;


extern NSMutableArray* keys;

-(id) getKPValue:(NSString*) key;
-(void)setKPValue:(id)value withKey:(NSString*)key;
-(void)setKPValueWithDictonary:(NSDictionary*)dictionary;

-(NSString*)getSignitureWithPath:(NSString*)path secret:(NSString*)secret method:(NSString*)method query:(NSDictionary*)data;
-(NSString*)HMAC_SHA1SignatureForText:(NSString *)inText usingSecret:(NSString *)inSecret;
-(ASIFormDataRequest*)addRequestWithDitionary:(ASIFormDataRequest*)request withDictionary:(NSDictionary*)data;
-(void)KPDataDebug;

+(KPData*)instance;
@end
