//
//  MyDelegate.h
//  KittypadSDK
//
//  Created by Chang Cheng on 6/18/11.
//  Copyright 2011 ChangCheng. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "KittypadDelegate.h"


@interface MyDelegate : NSObject <KittypadDelegate,UIAlertViewDelegate> {
    
}

@end
