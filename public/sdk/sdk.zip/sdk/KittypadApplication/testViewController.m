//
//  testViewController.m
//  test
//
//  Created by Linkou Bian on 5/12/11.
//  Copyright 2011 Kittypad. All rights reserved.
//

#import "testViewController.h"
#import "Kittypad.h"
#import "KPUpdate.h"
#import "KPData.h"
#import "TimeMgr.h"
#import "KPPostScore.h"


// should not include this file in the real app
// we add it here mainly to show game and edu GUI at the same app
#import "Kittypad+internal.h"

@implementation testViewController


/*
// The designated initializer. Override to perform setup that is required before the view is loaded.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/



// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
    
//#####################################SDK Comment start##############################################
//setting up the control dashboard and rest time, as well as the optional pause and continue function
    [Kittypad setBreakDelegate:self];
//#####################################SDK Comment end################################################    
}


//#####################################SDK Comment start##############################################
// setting pause and continue function
- (void)onPause {
    NSLog(@"**************onPause***********");
}
- (void)onResume {
    NSLog(@"@@@@@@@@@@@@@@onResume@@@@@@@@@@");
}
//#####################################SDK Comment end################################################  


// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {

//#####################################SDK Comment start##############################################    
// according to your own game settings set up the appropriate rotation settings
    
    //portrait
//    return UIInterfaceOrientationIsPortrait(interfaceOrientation);
    
    //landscape;
    return UIInterfaceOrientationIsLandscape(interfaceOrientation);
//#####################################SDK Comment end################################################
}

- (void)didRotateFromInterfaceOrientation:(UIInterfaceOrientation)fromInterfaceOrientation
{
	[Kittypad setDashboardOrientation:self.interfaceOrientation];
	[super didRotateFromInterfaceOrientation:fromInterfaceOrientation];
}

- (IBAction)startApplicationTest:(id)sender
{
//#####################################SDK Comment start##############################################    
//open the KittyPad control dashboard and adjust the event notification
    [Kittypad start];
//#####################################SDK Comment end################################################    
}

- (IBAction)startPauseTest:(id)sender
{
    [[TimeMgr instance]startPause ];
}

- (IBAction)startBreakTest:(id)sender
{
    [[TimeMgr instance]startBreak ];
}

- (IBAction)updateFromServer:(id)sender{
    [[KPUpdate instance]update];
}

- (IBAction)kpdebug:(id)sender{
    [[KPData instance] KPDataDebug];
}

- (IBAction)kptestposttime:(id)sender{
    [Kittypad shutdown];
}

- (IBAction)kptestpostscore:(id)sender{
//#####################################SDK Comment start##############################################     
// submit scores
    [Kittypad postScore:100];
//#####################################SDK Comment end################################################
}

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}

@end
