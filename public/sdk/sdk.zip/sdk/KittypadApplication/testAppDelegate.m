//
//  testAppDelegate.m
//  test
//
//  Created by Linkou Bian on 5/12/11.
//  Copyright 2011 Kittypad. All rights reserved.
//

#import "testAppDelegate.h"
#import "testViewController.h"
#import "Kittypad.h"
#import "MyDelegate.h"
#import "TimeMgr.h"

@implementation testAppDelegate

@synthesize window;
@synthesize viewController;


#pragma mark -
#pragma mark Application lifecycle

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {    

//#####################################SDK Comment start##############################################
    
//    the first parameter be assigning allocation files, the second parameter is program end proxy classes
//    the second parameter has two kinds of settings, if is it nil, then use the default prozy class, otherwise you won't be able to implement the Kittypad Delegate protocol
    [Kittypad initializeWithPlist:@"kp_config" andDelegate:[[MyDelegate alloc]init]];

//#####################################SDK Comment end################################################    
    
	// Set the view controller as the window's root view controller and display.
    self.window.rootViewController = self.viewController;
    [self.window makeKeyAndVisible];
    
    return YES;
}


- (void)applicationWillResignActive:(UIApplication *)application {
    /*
     Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
     Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
     */
//#####################################SDK Comment start##############################################
// transmit time information
    [Kittypad shutdown];
//#####################################SDK Comment end################################################
    
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    /*
     Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
     If your application supports background execution, called instead of applicationWillTerminate: when the user quits.
     */
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    /*
     Called as part of  transition from the background to the inactive state: here you can undo many of the changes made on entering the background.
     */
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    /*
     Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
     */
//#####################################SDK Comment start##############################################
// start time   
    [Kittypad resume];
//#####################################SDK Comment end################################################    
}


- (void)applicationWillTerminate:(UIApplication *)application {
    /*
     Called when the application is about to terminate.
     See also applicationDidEnterBackground:.
     */
}


#pragma mark -
#pragma mark Memory management

- (void)applicationDidReceiveMemoryWarning:(UIApplication *)application {
    /*
     Free up as much memory as possible by purging cached data objects that can be recreated (or reloaded from disk) later.
     */
}


- (void)dealloc {
	[Kittypad shutdown];
	
    [viewController release];
    [window release];
    [super dealloc];
}


@end
