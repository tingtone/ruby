//
//  testViewController.h
//  test
//
//  Created by Linkou Bian on 5/12/11.
//  Copyright 2011 Kittypad. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KittypadBreakDelegate.h"

//#####################################SDK Comment start##############################################
// setting up the control dashboard and rest time, as well as the optional pause and continue function
@interface testViewController : UIViewController<KittypadBreakDelegate> {
//#####################################SDK Comment end################################################    

}
- (IBAction)startApplicationTest:(id)sender;
- (IBAction)startPauseTest:(id)sender;
- (IBAction)startBreakTest:(id)sender;
- (IBAction)updateFromServer:(id)sender;
- (IBAction)kpdebug:(id)sender;
- (IBAction)kptestposttime:(id)sender;
- (IBAction)kptestpostscore:(id)sender;
@end

