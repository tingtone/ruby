//
//  KControllerLoader.m
//  KittypadSDK
//
//  Created by luke peng on 5/18/11.
//  Copyright 2011 kittypad. All rights reserved.
//

#import "KControllerLoader.h"
#import "Kittypad+internal.h"

@implementation KControllerLoader



static id loadObjectFromNib(NSString* nibName, id owner, Class classType)
{
	if(owner == nil)
	{
		owner = @"";
	}
    
	NSBundle* bundle = [Kittypad getResourceBundle];
    
	NSString* nibPath = [bundle pathForResource:nibName ofType:@"nib"];
	if (!nibPath)
	{
		bundle = [NSBundle mainBundle];
		nibPath = [bundle pathForResource:nibName ofType:@"nib"];
	}
	
	if ([nibPath length] > 0)
	{
		NSArray* objects = [bundle loadNibNamed:nibName owner:owner options:nil];
        
		for(unsigned int i = 0; i < [objects count]; ++i)
		{
			NSObject* obj = [objects objectAtIndex:i];
			if([obj isKindOfClass:classType]) 
			{
				return obj;
			}
		}
	}
	return nil;
}


+ (id)loader
{
    return [[KControllerLoader new] autorelease];
}


- (UIViewController*) load:(NSString*)name
{
    UIViewController* controller = nil;
    controller = loadObjectFromNib(name, nil, UIViewController.class);
    
    return controller;
}
@end
