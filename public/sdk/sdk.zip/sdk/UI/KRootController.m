
#import "KRootController.h"

@implementation KRootController

@synthesize containerView, bgOverlay, bgDropShadow;
@synthesize contentController, nonFullscreenModalController;
@synthesize transitionIn, transitionOut;

- (void)viewDidLoad
{
    
    self.containerView.backgroundColor = [UIColor clearColor];
    
    self.bgDropShadow = [[[UIImageView alloc] initWithFrame:containerView.bounds] autorelease];
    bgDropShadow.image = [[UIImage imageNamed:@"DashboardShadow.png"] stretchableImageWithLeftCapWidth:30.f topCapHeight:30.f];
    CGRect dashboardFrame = CGRectMake(3.f, 3.f, 1024.f, 768.f);
    bgDropShadow.frame = CGRectInset(dashboardFrame, -(dashboardFrame.origin.x), -(dashboardFrame.origin.y));
    [containerView insertSubview:bgDropShadow atIndex:0];
    
}

- (void)viewWillAppear:(BOOL)animated
{
	[super viewWillAppear:animated];
	
	
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(_keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(_keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
	
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];

    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillHideNotification object:nil];
	
}

- (void)_adjustController:(UIViewController*)controller toCompensateForKeyboard:(BOOL)shouldAdjust
{

}

- (void)_adjustForKeyboard:(UIInterfaceOrientation)orientation
{
	BOOL landscape = UIInterfaceOrientationIsLandscape(orientation);
	
	if (keyboardShowing && landscape)
	{
		CGPoint center = containerView.center;
		center.y = CGRectGetMidY(containerView.bounds) + 30.f;
		containerView.center = center;
	}
	else if (landscape)
	{
		CGPoint center = containerView.center;
		center.y = 373.f;
		containerView.center = center;
	}
	else
	{
		CGPoint center = containerView.center;
		center.y = 491.f;
		containerView.center = center;
	}

	[self _adjustController:contentController toCompensateForKeyboard:keyboardShowing && landscape];
}

- (void)_keyboardWillShow:(NSNotification*)notification
{
	if (keyboardShowing)
		return;
		
	keyboardShowing = YES;
}

- (void)_keyboardWillHide:(NSNotification*)notification
{
	if (!keyboardShowing)
		return;
		
	keyboardShowing = NO;

}

- (void)_dashboardWillRotate:(NSNotification*)notification
{
	if (!keyboardShowing)
		return;
}

- (void)animationDidStop:(CAAnimation*)_animation finished:(BOOL)_finished
{
	if (contentController.view.hidden)
	{
		[contentController viewDidDisappear:YES];
		[contentController.view removeFromSuperview];
		contentController.view = nil;
		[contentController release];
        contentController = nil;
	}
	else
	{
		[contentController viewDidAppear:YES];
	}
}

- (void)showController:(UIViewController*)_controller
{
    [contentController release];
	contentController = [_controller retain];
	[contentController viewWillAppear:YES];
    
    UIInterfaceOrientation orientation = [[UIApplication sharedApplication] statusBarOrientation];
    
    if (isPad) {
        if(orientation == UIInterfaceOrientationPortrait || 
           orientation == UIInterfaceOrientationPortraitUpsideDown) {
            contentController.view.frame = CGRectMake(0.f, 0.f, 768.f, 1024.f);
        }
        else if(orientation == UIInterfaceOrientationLandscapeLeft || 
                orientation == UIInterfaceOrientationLandscapeRight) {
            contentController.view.frame = CGRectMake(0.f, 0.f, 1024, 768.f);
        }
    }
    else {
        if(orientation == UIInterfaceOrientationPortrait || 
           orientation == UIInterfaceOrientationPortraitUpsideDown) {
            contentController.view.frame = CGRectMake(0.f, 0.f, 320.f, 480.f);
        }
        else if(orientation == UIInterfaceOrientationLandscapeLeft || 
                orientation == UIInterfaceOrientationLandscapeRight) {
            contentController.view.frame = CGRectMake(0.f, 0.f, 480.f, 320.f);
        }

    }
    
	[containerView addSubview:contentController.view];
    
    //to keep it from appearing underneath the background fader
    [containerView.superview bringSubviewToFront:containerView];
    
	CATransition* animation = [CATransition animation];
	animation.type = kCATransitionMoveIn;
	animation.subtype = transitionIn;
	animation.duration = 0.5f;
	animation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
	animation.delegate = self;
	[[containerView layer] addAnimation:animation forKey:nil];
    
    bgOverlay.alpha = 0.f;
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5f];
    bgOverlay.alpha = 1.f;
    [UIView commitAnimations];
}

- (void)hideController
{
	if (contentController == nil)
		return;
		
	[contentController viewWillDisappear:YES];

	CATransition* animation = [CATransition animation];
	animation.type = kCATransitionReveal;
	animation.subtype = transitionOut;
	animation.duration = 0.5f;
	animation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
	animation.delegate = self;
	[[containerView layer] addAnimation:animation forKey:nil];
    
	containerView.hidden = YES;
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5f];
    bgOverlay.alpha = 0.f;
    [UIView commitAnimations];    
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return YES;
}

- (void)presentNonFullScreenModalViewController:(UIViewController*)_modalViewController animated:(BOOL)animated
{
	self.nonFullscreenModalController = _modalViewController;
	[self.contentController.view addSubview:nonFullscreenModalController.view];
	[_modalViewController viewWillAppear:YES];
	nonFullscreenModalController.view.frame = self.contentController.view.bounds;;
	
	if (animated)
	{
		CATransition* animation = [CATransition animation];
		animation.type = kCATransitionMoveIn;
		animation.subtype = kCATransitionFromTop;
		animation.duration = 0.5f;
		animation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
		[[nonFullscreenModalController.view layer] addAnimation:animation forKey:nil];
	}
}

- (void)dismissNonFullScreenModalViewControllerAnimated:(BOOL)animated
{
	nonFullscreenModalController.view.hidden = YES;
	
	if (animated)
	{
		CATransition* animation = [CATransition animation];
		animation.type = kCATransitionReveal;
		animation.subtype = kCATransitionFromBottom;
		animation.duration = 0.5f;
		animation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
		[[nonFullscreenModalController.view layer] addAnimation:animation forKey:nil];
		
		nonFullscreenModalController.view.hidden = YES;
	}
}

- (void)presentModalViewController:(UIViewController *)_modalViewController animated:(BOOL)animated
{
    
    [self presentNonFullScreenModalViewController:_modalViewController animated:animated];
}

- (void)dismissModalViewControllerAnimated:(BOOL)animated
{
    
    [self dismissNonFullScreenModalViewControllerAnimated:animated];
}

- (UIViewController*)modalViewController
{
	if (nonFullscreenModalController != nil)
		return nonFullscreenModalController;
		
	return [super modalViewController];
}

- (void)cleanupSubviews {
    while([[self.view subviews] count] > 0)
    {
        UIView *aSubview = [[self.view subviews] objectAtIndex:0];
        [aSubview removeFromSuperview];
    }
}

- (void)dealloc
{
	[contentController release];
    [nonFullscreenModalController release];
	[containerView release];
    [bgOverlay release];
    [bgDropShadow release];
    
	self.transitionIn = nil;
	self.transitionOut = nil;

	[super dealloc];
}

@end