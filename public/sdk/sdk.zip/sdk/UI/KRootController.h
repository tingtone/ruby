
#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>

#define isPad (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)

@protocol KKeyboardAdjustment
@required
- (CGFloat)_keyboardAdjustment;
@end

@interface KRootController : UIViewController
{
@package
	UIView* containerView;
    UIView* bgOverlay;
    UIImageView *bgDropShadow;
    
	UIViewController* contentController;
    UIViewController* nonFullscreenModalController;
	
	NSString* transitionIn;
	NSString* transitionOut;
	
	BOOL keyboardShowing;
}

@property (nonatomic, retain) IBOutlet UIView *containerView;
@property (nonatomic, retain) IBOutlet UIView* bgOverlay;
@property (nonatomic, retain) UIImageView* bgDropShadow;

@property (nonatomic, readonly) UIViewController* contentController;
@property (nonatomic, retain) UIViewController* nonFullscreenModalController;

@property (nonatomic, retain) NSString* transitionIn;
@property (nonatomic, retain) NSString* transitionOut;

- (void)showController:(UIViewController*)_controller;
- (void)hideController;

- (void)cleanupSubviews;

- (void)presentNonFullScreenModalViewController:(UIViewController*)_modalViewController animated:(BOOL)animated;
- (void)dismissNonFullScreenModalViewControllerAnimated:(BOOL)animated;

@end