//
//  ChangeLinksController.m
//  KittypadSDK
//
//  Created by de meng on 7/3/11.
//  Copyright 2011 Kittypad. All rights reserved.
//

#import "ChangeLinksController.h"
#import "Kittypad.h"
#import "Kittypad+internal.h"
#import "KittyUtil.h"
#import "KPData.h"

@implementation ChangeLinksController

@synthesize webView, indicatorView;
@synthesize backButton;


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.title = @"Recommend";
        UIImage* tabImage = [UIImage imageWithContentsOfFile:[[Kittypad getResourceBundle] pathForResource:@"ChangeLinks" ofType:@"png"]];
        
        self.tabBarItem = [[[UITabBarItem alloc] initWithTitle:KittyUtil::getLocalizedString(@"lbl_recommend", @"recommend") image:tabImage tag:0] autorelease];

    }
    return self;
}

- (void)dealloc
{
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    backButton.hidden = [Kittypad getBackButtonHiddenInternal];
    
    if ([[KPData instance] getKPValue:kEmail] != nil) {
        backButton.hidden = NO;
    }
    
    // For localization
    NSString* backButtonTitle = KittyUtil::getLocalizedString(@"btn_back", @"Back to App");
    [backButton setTitle:backButtonTitle forState:UIControlStateNormal];
    
    NSLog(@"%@-%@", [Kittypad getKey], [[UIDevice currentDevice] uniqueIdentifier]);
    
    NSString *url = [NSString stringWithFormat:@"%@apps?key=%@&device=%@", [Kittypad getServerUrl], [Kittypad getKey], [[UIDevice currentDevice] uniqueIdentifier]];
    [self.webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:url]]];
    webView.delegate = self;
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
    
    self.webView = nil;
    self.indicatorView = nil;
    self.backButton = nil;

}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
	return YES;
}

- (IBAction) back
{
    [Kittypad dismissDashboard];
}

- (void )webViewDidFinishLoad:(UIWebView *)webView {
    [indicatorView stopAnimating];
    indicatorView.hidden = YES;
}

- (void )webViewDidStartLoad:(UIWebView *)webView {     
    [indicatorView startAnimating];
    indicatorView.hidden = NO;
}

@end
