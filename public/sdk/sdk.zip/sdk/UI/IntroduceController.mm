//
//  IntroduceController.m
//  KittypadSDK
//
//  Created by de meng on 7/3/11.
//  Copyright 2011 Kittypad. All rights reserved.
//

#import "IntroduceController.h"
#import "Kittypad.h"
#import "Kittypad+internal.h"
#import "KittyUtil.h"
#import "KPData.h"

@implementation IntroduceController

@synthesize webView, indicatorView, imageView;
@synthesize introduce_comment1, introduce_comment2, introduce_comment3;
@synthesize backButton, wantButton;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.title = @"Introduce";
        UIImage* tabImage = [UIImage imageWithContentsOfFile:[[Kittypad getResourceBundle] pathForResource:@"Introduce" ofType:@"png"]];

        if ([[KPData instance] getKPValue:kEmail] == nil) {
        self.tabBarItem = [[[UITabBarItem alloc] initWithTitle:KittyUtil::getLocalizedString(@"lbl_introduce", @"Introduce") image:tabImage tag:0] autorelease];
        }
        else {
            self.tabBarItem = [[[UITabBarItem alloc] initWithTitle:KittyUtil::getLocalizedString(@"lbl_about", @"About") image:tabImage tag:0] autorelease];            
        }
    }
    return self;
}

- (void)dealloc
{
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    backButton.hidden = [Kittypad getBackButtonHiddenInternal];
    
    NSLocale* currentLocale = [NSLocale currentLocale];
    NSLog(@"currentLocale = %@", [currentLocale localeIdentifier]); 
    NSString *local = [NSString stringWithString:[[currentLocale localeIdentifier]substringToIndex:2]];
    
    // For localization
    NSString* backButtonTitle = KittyUtil::getLocalizedString(@"btn_back", @"Back to App");
    [backButton setTitle:backButtonTitle forState:UIControlStateNormal];
    
    introduce_comment1.hidden = YES;
    introduce_comment2.hidden = YES;
    introduce_comment3.hidden = YES;    
    
    if ([[KPData instance] getKPValue:kEmail] == nil)
    {
        webView.hidden = YES;
        indicatorView.hidden = YES;
        wantButton.hidden = NO;
        
        UIInterfaceOrientation orientation = [[UIApplication sharedApplication] statusBarOrientation]; 
        if (isPad) {
            if ([local isEqualToString:@"zh"]) {
                if(orientation == UIInterfaceOrientationPortrait ||
                   orientation == UIInterfaceOrientationPortraitUpsideDown) {
                    imageView.image = [UIImage imageWithContentsOfFile:[[Kittypad getResourceBundle] pathForResource:@"introduce_screen768_1024_cn" ofType:@"png"]];
                }
                else if(orientation == UIInterfaceOrientationLandscapeLeft ||
                        orientation == UIInterfaceOrientationLandscapeRight) {
                    imageView.image = [UIImage imageWithContentsOfFile:[[Kittypad getResourceBundle] pathForResource:@"introduce_screen1024_768_cn" ofType:@"png"]];
                }
                
                [wantButton setImage:[UIImage imageWithContentsOfFile:[[Kittypad getResourceBundle] pathForResource:@"ipad_button_normal_cn" ofType:@"png"]] forState:UIControlStateNormal];
            }
            else if([local isEqualToString:@"fr"] ||
                    [local isEqualToString:@"de"] ||
                    [local isEqualToString:@"es"] ||
                    [local isEqualToString:@"pt"] ||
                    [local isEqualToString:@"it"] ||
                    [local isEqualToString:@"ru"] ||
                    [local isEqualToString:@"ja"] ||
                    [local isEqualToString:@"ko"]) {
                
                introduce_comment1.hidden = NO;
                introduce_comment2.hidden = NO;
                introduce_comment3.hidden = NO; 
                
                introduce_comment1.text = KittyUtil::getLocalizedString(@"lbl_Introduce_comment1", @"Worried about your eyesight? ");
                introduce_comment2.text = KittyUtil::getLocalizedString(@"lbl_Introduce_comment2", @"Missed meals due to being lost in a game? ");
                introduce_comment3.text = KittyUtil::getLocalizedString(@"lbl_Introduce_comment3", @"Can't find the right educational games? ");
                
                [wantButton setTitle:@"OK" forState:UIControlStateNormal];
                [wantButton setImage:nil forState:UIControlStateNormal];
                [wantButton setBackgroundImage:[UIImage imageWithContentsOfFile:[[Kittypad getResourceBundle] pathForResource:@"u12" ofType:@"png"]] forState:UIControlStateNormal];

                
            }
            else {
                if(orientation == UIInterfaceOrientationPortrait ||
                   orientation == UIInterfaceOrientationPortraitUpsideDown) {
                    imageView.image = [UIImage imageWithContentsOfFile:[[Kittypad getResourceBundle] pathForResource:@"introduce_screen768_1024_en" ofType:@"png"]];
                }
                else if(orientation == UIInterfaceOrientationLandscapeLeft ||
                        orientation == UIInterfaceOrientationLandscapeRight) {
                    imageView.image = [UIImage imageWithContentsOfFile:[[Kittypad getResourceBundle] pathForResource:@"introduce_screen1024_768_en" ofType:@"png"]];
                }
                [wantButton setImage:[UIImage imageWithContentsOfFile:[[Kittypad getResourceBundle] pathForResource:@"ipad_button_normal_en" ofType:@"png"]] forState:UIControlStateNormal];
            }
        }
        else {
            if ([local isEqualToString:@"zh"]) {
                if(orientation == UIInterfaceOrientationPortrait ||
                   orientation == UIInterfaceOrientationPortraitUpsideDown) {
                    imageView.image = [UIImage imageWithContentsOfFile:[[Kittypad getResourceBundle] pathForResource:@"introduce_screen320_480_cn" ofType:@"png"]];
                }
                else if(orientation == UIInterfaceOrientationLandscapeLeft ||
                        orientation == UIInterfaceOrientationLandscapeRight) {
                    imageView.image = [UIImage imageWithContentsOfFile:[[Kittypad getResourceBundle] pathForResource:@"introduce_screen480_320_cn" ofType:@"png"]];
                }
                [wantButton setImage:[UIImage imageWithContentsOfFile:[[Kittypad getResourceBundle] pathForResource:@"iphone_button_normal_cn" ofType:@"png"]] forState:UIControlStateNormal];
            }
            else if([local isEqualToString:@"fr"] ||
                    [local isEqualToString:@"de"] ||
                    [local isEqualToString:@"es"] ||
                    [local isEqualToString:@"pt"] ||
                    [local isEqualToString:@"it"] ||
                    [local isEqualToString:@"ru"] ||
                    [local isEqualToString:@"zh"] ||
                    [local isEqualToString:@"ja"] ||
                    [local isEqualToString:@"ko"]) {
                introduce_comment1.hidden = NO;
                introduce_comment2.hidden = NO;
                introduce_comment3.hidden = NO; 
                
                introduce_comment1.text = KittyUtil::getLocalizedString(@"lbl_Introduce_comment1", @"Worried about your eyesight? ");
                introduce_comment2.text = KittyUtil::getLocalizedString(@"lbl_Introduce_comment2", @"Missed meals due to being lost in a game? ");
                introduce_comment3.text = KittyUtil::getLocalizedString(@"lbl_Introduce_comment3", @"Can't find the right educational games? ");
                
                [wantButton setTitle:@"OK" forState:UIControlStateNormal];
                [wantButton setImage:nil forState:UIControlStateNormal];
                [wantButton setBackgroundImage:[UIImage imageWithContentsOfFile:[[Kittypad getResourceBundle] pathForResource:@"u12" ofType:@"png"]] forState:UIControlStateNormal];
            }
            else {
                if(orientation == UIInterfaceOrientationPortrait ||
                   orientation == UIInterfaceOrientationPortraitUpsideDown) {
                    imageView.image = [UIImage imageWithContentsOfFile:[[Kittypad getResourceBundle] pathForResource:@"introduce_screen320_480_en" ofType:@"png"]];
                }
                else if(orientation == UIInterfaceOrientationLandscapeLeft ||
                        orientation == UIInterfaceOrientationLandscapeRight) {
                    imageView.image = [UIImage imageWithContentsOfFile:[[Kittypad getResourceBundle] pathForResource:@"introduce_screen480_320_en" ofType:@"png"]];
                }
                [wantButton setImage:[UIImage imageWithContentsOfFile:[[Kittypad getResourceBundle] pathForResource:@"iphone_button_normal_en" ofType:@"png"]] forState:UIControlStateNormal];
            }
        }
    }
    else {
        backButton.hidden = NO;
        imageView.hidden = YES;
        webView.hidden = NO;
        indicatorView.hidden = YES;
        wantButton.hidden = YES;
        NSString *url = [NSString stringWithFormat:@"%@owners?device=%@", [Kittypad getServerUrl], [[UIDevice currentDevice] uniqueIdentifier]];
        [self.webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:url]]];
        webView.delegate = self;
    }

}

- (void) handleBack:(id)sender
{
//    [self.navigationController.view removeFromSuperview];
    [Kittypad popController];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
    
    self.webView = nil;
    self.indicatorView = nil;
    self.backButton = nil;
    self.wantButton = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
	return YES;
}

- (IBAction) back
{
    [Kittypad dismissDashboard];
}

- (void )webViewDidFinishLoad:(UIWebView *)webView {
    [indicatorView stopAnimating];
    indicatorView.hidden = YES;
}

- (void )webViewDidStartLoad:(UIWebView *)webView {     
    [indicatorView startAnimating];
    indicatorView.hidden = NO;
}

- (IBAction) gotoSetting
{
    UITabBarController* tabController = [Kittypad getTabController];
    [tabController setSelectedIndex:0]; 
}

@end
