//
//  ChangeLinksController.h
//  KittypadSDK
//
//  Created by de meng on 7/3/11.
//  Copyright 2011 Kittypad. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface ChangeLinksController : UIViewController <UIWebViewDelegate> {
    
    UIWebView *webView;
    UIActivityIndicatorView *indicatorView;
    
    //Localizable
    UIButton *backButton;
    
}

@property(nonatomic, retain) IBOutlet UIWebView *webView;
@property(nonatomic, retain) IBOutlet UIActivityIndicatorView *indicatorView;
@property(nonatomic, retain) IBOutlet UIButton *backButton;

- (IBAction) back;

@end
