//
//  SettingController.h
//  KittypadSDK
//
//  Created by de meng on 7/3/11.
//  Copyright 2011 Kittypad. All rights reserved.
//

#import <UIKit/UIKit.h>

#define isPad (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)

@interface SettingController : UIViewController <UIAlertViewDelegate>{
    
    UIScrollView *scrollView;
    
    UITextField *emailField;
    UITextField *passwordField;
    UILabel *emaiContentlLabel;
    
    UITextField *name;
    UIDatePicker *birthday;
    UISegmentedControl *sex;
    
    UITextField *total_day_left_time;
    UITextField *total_week_left_time;
    UILabel *bonusTime;

    UITextField *short_time;
    UITextField *long_time;
    
    UIActivityIndicatorView *indicatorView;
    
    //Localizable
    UIButton *backButton;
    UIButton *saveButton;
    
    UILabel *ownerInfoLabel;
    UILabel *emailLabel;
    UILabel *passwordlLabel;

    UILabel *userInfoLabel;
    UILabel *nameLabel;
    UILabel *birthdayLabel;
    UILabel *sexLabel;

    UILabel *timeControlLabel;   
    UILabel *forAllThisGameLabel;    
    UILabel *totalDayLeftTimeLabel;
    UILabel *minutesForTotalDayLeftTimeLabel;
    UILabel *totalWeekLeftTimeLabel;
    UILabel *minutesForTotalWeekLeftTimeLabel;    
    UILabel *bonusTimeLabel;
    UILabel *minutesForBonusTimeLabel;

    UILabel *healthProtectionLabel;
    UILabel *shortBreakLabel;
    UILabel *minutesForShortBreakLabel;
    UILabel *longBreakLabel;
    UILabel *minutesForLongBreakLabel;
    
    NSMutableDictionary * pendingData;
    
    BOOL isUpdate;
    
}

@property(nonatomic, retain) IBOutlet UIScrollView *scrollView;
@property(nonatomic, retain) IBOutlet UITextField* emailField;
@property(nonatomic, retain) IBOutlet UITextField* passwordField;
@property(nonatomic, retain) IBOutlet UILabel* emaiContentlLabel;
@property(nonatomic, retain) IBOutlet UITextField *name;
@property(nonatomic, retain) IBOutlet UIDatePicker *birthday;
@property(nonatomic, retain) IBOutlet UISegmentedControl *sex;
@property(nonatomic, retain) IBOutlet UITextField *total_day_left_time;
@property(nonatomic, retain) IBOutlet UITextField *total_week_left_time;
@property(nonatomic, retain) IBOutlet UILabel *bonusTime;
@property(nonatomic, retain) IBOutlet UITextField *short_time;
@property(nonatomic, retain) IBOutlet UITextField *long_time;
@property(nonatomic, retain) IBOutlet UIActivityIndicatorView *indicatorView;

@property(nonatomic, retain) IBOutlet UIButton *backButton;
@property(nonatomic, retain) IBOutlet UIButton *saveButton;
@property(nonatomic, retain) IBOutlet UILabel *ownerInfoLabel;
@property(nonatomic, retain) IBOutlet UILabel *emailLabel;
@property(nonatomic, retain) IBOutlet UILabel *passwordlLabel;
@property(nonatomic, retain) IBOutlet UILabel *userInfoLabel;
@property(nonatomic, retain) IBOutlet UILabel *nameLabel;
@property(nonatomic, retain) IBOutlet UILabel *birthdayLabel;
@property(nonatomic, retain) IBOutlet UILabel *sexLabel;
@property(nonatomic, retain) IBOutlet UILabel *timeControlLabel;
@property(nonatomic, retain) IBOutlet UILabel *forAllThisGameLabel;
@property(nonatomic, retain) IBOutlet UILabel *totalDayLeftTimeLabel;
@property(nonatomic, retain) IBOutlet UILabel *minutesForTotalDayLeftTimeLabel;
@property(nonatomic, retain) IBOutlet UILabel *totalWeekLeftTimeLabel;
@property(nonatomic, retain) IBOutlet UILabel *minutesForTotalWeekLeftTimeLabel;
@property(nonatomic, retain) IBOutlet UILabel *bonusTimeLabel;
@property(nonatomic, retain) IBOutlet UILabel *minutesForBonusTimeLabel;
@property(nonatomic, retain) IBOutlet UILabel *healthProtectionLabel;
@property(nonatomic, retain) IBOutlet UILabel *shortBreakLabel;
@property(nonatomic, retain) IBOutlet UILabel *minutesForShortBreakLabel;
@property(nonatomic, retain) IBOutlet UILabel *longBreakLabel;
@property(nonatomic, retain) IBOutlet UILabel *minutesForLongBreakLabel;

@property(nonatomic, retain)NSMutableDictionary * pendingData;
@property(nonatomic, assign)BOOL isUpdate;

- (IBAction) back;
- (IBAction) save;
- (IBAction) textFieldDoneEditing:(id)sender;
- (IBAction) backgroundTap:(id)sender;
- (IBAction) changeDate:(id)sender;

- (BOOL) NSStringIsValidEmail:(NSString *)checkString;
- (BOOL) NSStringIsValidNumber:(NSString *)checkString;
- (bool) checkInput;

@end
