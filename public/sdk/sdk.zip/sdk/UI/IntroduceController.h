//
//  IntroduceController.h
//  KittypadSDK
//
//  Created by de meng on 7/3/11.
//  Copyright 2011 Kittypad. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface IntroduceController : UIViewController <UIWebViewDelegate> {
    
    UIWebView *webView;
    UIActivityIndicatorView *indicatorView;
    UIImageView *imageView;
    UILabel *introduce_comment1;
    UILabel *introduce_comment2;
    UILabel *introduce_comment3;    
    
    //Localizable
    UIButton *backButton;
    UIButton *wantButton;
    
}

@property(nonatomic, retain) IBOutlet UIWebView *webView;
@property(nonatomic, retain) IBOutlet UIActivityIndicatorView *indicatorView;
@property(nonatomic, retain) IBOutlet UIImageView *imageView;
@property(nonatomic, retain) IBOutlet UILabel *introduce_comment1;
@property(nonatomic, retain) IBOutlet UILabel *introduce_comment2;
@property(nonatomic, retain) IBOutlet UILabel *introduce_comment3;
@property(nonatomic, retain) IBOutlet UIButton *backButton;
@property(nonatomic, retain) IBOutlet UIButton *wantButton;

- (IBAction) back;
- (IBAction) gotoSetting;

@end
