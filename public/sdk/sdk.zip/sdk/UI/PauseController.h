//
//  PauseController.h
//  KittypadSDK
//
//  Created by de meng on 7/8/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>


@interface PauseController : UIViewController {
    AVAudioPlayer *myBackMusic;
    
    UIButton *changeSettingButton;
    UIButton *pauseButton;
    UIImageView *imageView;
    
    int type;
}

@property (nonatomic, retain) IBOutlet UIButton *changeSettingButton;
@property (nonatomic, retain) IBOutlet UIButton *pauseButton;
@property (nonatomic, retain) IBOutlet UIImageView *imageView;

@property (nonatomic, retain) AVAudioPlayer *myBackMusic;
@property (nonatomic, assign) int type;
@property (nonatomic, assign) BOOL isChangeSettingButtonPress;

- (IBAction) changeSetting:(id)sender;
- (IBAction) pause:(id)sender;
- (void) stopMusic;

@end
