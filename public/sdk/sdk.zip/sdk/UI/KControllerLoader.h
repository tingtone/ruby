//
//  KControllerLoader.h
//  KittypadSDK
//
//  Created by luke peng on 5/18/11.
//  Copyright 2011 kittypad. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface KControllerLoader : NSObject {
    
}

+ (id)loader;
- (UIViewController*) load:(NSString*)name;

@end
