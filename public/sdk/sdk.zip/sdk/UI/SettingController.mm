#import "KPData.h"
#import "SettingController.h"
#import "Kittypad.h"
#import "Kittypad+internal.h"
#import "KittyUtil.h"
#import "ASIFormDataRequest.h"
#import "CJSONDeserializer.h"

@implementation SettingController

@synthesize scrollView;
@synthesize emailField, passwordField, emaiContentlLabel;
@synthesize name, birthday, sex;
@synthesize total_day_left_time, total_week_left_time, bonusTime;
@synthesize short_time, long_time;
@synthesize indicatorView;
@synthesize backButton, saveButton;
@synthesize ownerInfoLabel, emailLabel, passwordlLabel;
@synthesize userInfoLabel, nameLabel, birthdayLabel, sexLabel;
@synthesize timeControlLabel, forAllThisGameLabel, totalDayLeftTimeLabel, minutesForTotalDayLeftTimeLabel, totalWeekLeftTimeLabel, minutesForTotalWeekLeftTimeLabel, bonusTimeLabel, minutesForBonusTimeLabel;
@synthesize healthProtectionLabel, shortBreakLabel, minutesForShortBreakLabel, longBreakLabel, minutesForLongBreakLabel;

@synthesize pendingData, isUpdate;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.title = @"Setting";
        UIImage* tabImage = [UIImage imageWithContentsOfFile:[[Kittypad getResourceBundle] pathForResource:@"Setting" ofType:@"png"]];
        
        self.tabBarItem = [[[UITabBarItem alloc] initWithTitle:KittyUtil::getLocalizedString(@"lbl_setting", @"Setting") image:tabImage tag:0] autorelease];
        
    }
    return self;
}

- (void)dealloc
{
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    backButton.hidden = [Kittypad getBackButtonHiddenInternal];
    
    NSLocale* currentLocale = [NSLocale currentLocale];
    
    // For localization  
    NSString* backButtonTitle = KittyUtil::getLocalizedString(@"btn_back", @"Back to App");
    [backButton setTitle:backButtonTitle forState:UIControlStateNormal];
    NSString* saveButtonTitle = KittyUtil::getLocalizedString(@"btn_save", @"Save");
    [saveButton setTitle:saveButtonTitle forState:UIControlStateNormal];
    
    ownerInfoLabel.text = KittyUtil::getLocalizedString(@"lbl_ownerInfo", @"Owner Information");
    emailLabel.text = KittyUtil::getLocalizedString(@"lbl_email", @"Email");
    passwordlLabel.text = KittyUtil::getLocalizedString(@"lbl_password", @"Password");
    
    userInfoLabel.text = KittyUtil::getLocalizedString(@"lbl_userInfo", @"User Information");
    nameLabel.text = KittyUtil::getLocalizedString(@"lbl_name", @"Name");
    sexLabel.text = KittyUtil::getLocalizedString(@"lbl_sex", @"Gender");
    NSString* sexBoyText = KittyUtil::getLocalizedString(@"sc_boy", @"Boy");
    NSString* sexGirlText = KittyUtil::getLocalizedString(@"sc_girl", @"Girl");
    [sex setTitle:sexBoyText forSegmentAtIndex:0];
    [sex setTitle:sexGirlText forSegmentAtIndex:1];    
    birthdayLabel.text = KittyUtil::getLocalizedString(@"lbl_birthday", @"Birthday");
    
    timeControlLabel.text = KittyUtil::getLocalizedString(@"lbl_timeControl", @"Time Control");
    forAllThisGameLabel.text = KittyUtil::getLocalizedString(@"lbl_forAllThisGame", @"For all games that are in the kittypad network:");
    totalDayLeftTimeLabel.text = KittyUtil::getLocalizedString(@"lbl_totalDayLeftTime", @"allowed minutes on weekday");
    minutesForTotalDayLeftTimeLabel.text = KittyUtil::getLocalizedString(@"lbl_minutes", @"minutes");
    totalWeekLeftTimeLabel.text = KittyUtil::getLocalizedString(@"lbl_totalWeekLeftTime", @"allowed minutes on weekend");
    minutesForTotalWeekLeftTimeLabel.text = KittyUtil::getLocalizedString(@"lbl_minutes", @"minutes");
    bonusTimeLabel.text = KittyUtil::getLocalizedString(@"lbl_bonusTime", @"Bonus time:");
    minutesForBonusTimeLabel.text = KittyUtil::getLocalizedString(@"lbl_minutes", @"minutes");
    
    healthProtectionLabel.text = KittyUtil::getLocalizedString(@"lbl_healthProtection", @"Breaks");
    shortBreakLabel.text = KittyUtil::getLocalizedString(@"lbl_shortBreak", @"Short Break");
    minutesForShortBreakLabel.text = KittyUtil::getLocalizedString(@"lbl_minutes", @"minutes");    
    longBreakLabel.text = KittyUtil::getLocalizedString(@"lbl_longBreak", @"Long Break");
    minutesForLongBreakLabel.text = KittyUtil::getLocalizedString(@"lbl_minutes", @"minutes");  
    
    [scrollView setContentSize:CGSizeMake(0.f, 10.f)];

    birthday.locale = currentLocale;
    
    isUpdate = FALSE;

    if ([[KPData instance] getKPValue:kEmail] == nil) {
        emaiContentlLabel.hidden = TRUE;
        emailField.hidden = FALSE;

        NSDate *now = [NSDate date];
        int yearsToAdd = -7;
        NSDateComponents *components = [[[NSDateComponents alloc] init] autorelease];
        [components setYear:yearsToAdd];
        NSCalendar *gregorian = [[[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar] autorelease];
        NSDate *newDate2 = [gregorian dateByAddingComponents:components toDate:now options:0];
        birthday.date = newDate2;
        birthday.maximumDate = [NSDate date];
        [self changeDate:nil];
    }
    else {
        
        backButton.hidden = NO;
        
        isUpdate = TRUE;
        
        emaiContentlLabel.hidden = FALSE;
        emaiContentlLabel.text = [[KPData instance] getKPValue:kEmail];
        emailField.hidden = TRUE;
        emailField.text = [[KPData instance] getKPValue:kEmail];

        [name setText:[[KPData instance] getKPValue:kPlayerName]];
        
        [sex setSelectedSegmentIndex:[[[KPData instance] getKPValue:kPlayerGender]intValue]];
        [birthday setDate:[[KPData instance] getKPValue:kPlayerBirthday]];
        
        [total_day_left_time setText:[NSString stringWithFormat:@"%ld", [[[KPData instance] getKPValue:kWeekday_time]longLongValue]/60]];
        [total_week_left_time setText:[NSString stringWithFormat:@"%ld", [[[KPData instance] getKPValue:kWeekend_time]longLongValue]/60]];
        [short_time setText:[NSString stringWithFormat:@"%ld", [[[KPData instance] getKPValue:kInteval_pause]longLongValue]/60]];
        [long_time setText:[NSString stringWithFormat:@"%ld", [[[KPData instance] getKPValue:kInteval_break]longLongValue]/60]];

//  ***test:second***
//        if ([[[KPData instance] getKPValue:kWeekday_time] isKindOfClass:[NSString class]]){
//            [total_day_left_time setText:[[KPData instance] getKPValue:kWeekday_time]];
//        }
//        else if([[[KPData instance] getKPValue:kWeekday_time] isKindOfClass:[NSNumber class]]){
//            [total_day_left_time setText:[[[KPData instance] getKPValue:kWeekday_time]stringValue]];
//        }
//        
//        if ([[[KPData instance] getKPValue:kWeekend_time] isKindOfClass:[NSString class]]){
//            [total_week_left_time setText:[[KPData instance] getKPValue:kWeekend_time]];
//        }
//        else if([[[KPData instance] getKPValue:kWeekend_time] isKindOfClass:[NSNumber class]]){
//            [total_week_left_time setText:[[[KPData instance] getKPValue:kWeekend_time]stringValue]];
//        }
//        
//        if ([[[KPData instance] getKPValue:kInteval_pause] isKindOfClass:[NSString class]]){
//            [short_time setText:[[KPData instance] getKPValue:kInteval_pause]];
//        }
//        else if([[[KPData instance] getKPValue:kInteval_pause] isKindOfClass:[NSNumber class]]){
//            [short_time setText:[[[KPData instance] getKPValue:kInteval_pause]stringValue]];
//        }   
//        
//        if ([[[KPData instance] getKPValue:kInteval_break] isKindOfClass:[NSString class]]){
//            [long_time setText:[[KPData instance] getKPValue:kInteval_break]];
//        }
//        else if([[[KPData instance] getKPValue:kInteval_break] isKindOfClass:[NSNumber class]]){
//            [long_time setText:[[[KPData instance] getKPValue:kInteval_break]stringValue]];
//        }
//  ***test:second*** 
        
    }
    
    indicatorView.hidden = TRUE;
    pendingData = [[NSMutableDictionary alloc] init];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
    
    self.scrollView = nil;
    self.emailField = nil;
    self.passwordField = nil;
    self.emaiContentlLabel = nil;
    self.name = nil;
    self.birthday = nil;
    self.sex = nil;
    self.total_day_left_time = nil;
    self.total_week_left_time = nil;
    self.bonusTime = nil;
    self.short_time = nil;
    self.long_time = nil;
    self.indicatorView = nil;
    
    self.backButton = nil;
    [pendingData release];

}


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{    
    // Return YES for supported orientations
	return YES;
}

- (IBAction)textFieldDoneEditing:(id)sender
{
    [sender resignFirstResponder];
}

- (IBAction) backgroundTap:(id)sender
{
    [emailField resignFirstResponder];
    [passwordField resignFirstResponder];
    [name resignFirstResponder];
    [total_day_left_time resignFirstResponder];
    [total_week_left_time resignFirstResponder];
    [short_time resignFirstResponder];
    [long_time resignFirstResponder];
    
}

- (IBAction) back
{
    [Kittypad dismissDashboard];
}

- (BOOL) NSStringIsValidEmail:(NSString *)checkString
{
    BOOL stricterFilter = YES;
    NSString *stricterFilterString = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSString *laxString = @".+@.+\\.[A-Za-z]{2}[A-Za-z]*";
    NSString *emailRegex = stricterFilter ? stricterFilterString : laxString;
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:checkString];
}

- (BOOL) NSStringIsValidNumber:(NSString *)checkString
{
    NSPredicate *numberTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", @"[0-9]+"];
    return [numberTest evaluateWithObject:checkString];
}

- (bool) checkInput
{
    if (emailField.text == nil || emailField.text.length == 0|| 
        passwordField.text == nil || passwordField.text.length == 0 ||
        name.text == nil || name.text.length == 0 ||
        total_day_left_time.text == nil || total_day_left_time.text.length == 0 ||
        total_week_left_time.text == nil || total_week_left_time.text.length == 0 ||
        short_time.text == nil || short_time.text.length == 0 ||
        long_time.text == nil || long_time.text.length == 0) {

        [[[[UIAlertView alloc]
           initWithTitle:@"Error"
           message:@"Enter a valid value !!!"
           delegate:nil
           cancelButtonTitle:@"Ok"
           otherButtonTitles:nil] autorelease] show];
        
        return FALSE;
    }
    
    if (passwordField.text.length < 6) {
        [[[[UIAlertView alloc]
           initWithTitle:@"Error"
           message:@"Password lenth must >= 6 !!!"
           delegate:nil
           cancelButtonTitle:@"Ok"
           otherButtonTitles:nil] autorelease] show];
        
        return FALSE;
    }
    
    
    if (![self NSStringIsValidEmail:emailField.text]) {
        
        [[[[UIAlertView alloc]
           initWithTitle:@"Error"
           message:@"Enter a valid email address !!!"
           delegate:nil
           cancelButtonTitle:@"Ok"
           otherButtonTitles:nil] autorelease] show];
        
        return FALSE;
    }
    
    if (![self NSStringIsValidNumber:total_day_left_time.text] ||
        ![self NSStringIsValidNumber:total_week_left_time.text] ||
        ![self NSStringIsValidNumber:short_time.text] ||
        ![self NSStringIsValidNumber:long_time.text]) {
        
        [[[[UIAlertView alloc]
           initWithTitle:@"Error"
           message:@"Enter a valid time value !!!"
           delegate:nil
           cancelButtonTitle:@"Ok"
           otherButtonTitles:nil] autorelease] show];
        
        return FALSE;
    }
    
    return TRUE;
}

-(NSNumber*) StringToNumber:(NSString*)string{
    return [NSNumber numberWithInt:[string intValue]];
}

- (IBAction) save
{
    [self backgroundTap:nil];
    
    if (![self checkInput]) {
        return;
    }
    

    indicatorView.hidden = FALSE;
    [indicatorView startAnimating];

    //prepare for the request and sig
    [pendingData setObject:emailField.text forKey:kOwnerName];
    [pendingData setObject:emailField.text forKey:kEmail];
    [pendingData setObject:passwordField.text forKey:kPassword];
    
    //device id;
    NSString *udid = [[UIDevice currentDevice] uniqueIdentifier];
    [pendingData setObject:udid forKey:kDeviceID];
    
    if(isPad)
        [pendingData setObject:@"iPad" forKey:kAgent];
    else
        [pendingData setObject:@"iPhone" forKey:kAgent];
    
    NSLocale* currentLocale = [NSLocale currentLocale];
    [pendingData setObject:[[currentLocale localeIdentifier]substringToIndex:2] forKey:kLanguage];
    
    [pendingData setObject:name.text forKey:kPlayerName];
    
    [pendingData setObject:[NSNumber numberWithInt:[sex selectedSegmentIndex]] forKey:kPlayerGender];
    [pendingData setObject:birthday.date forKey:kPlayerBirthday];
    
    [pendingData setObject:[NSNumber numberWithLongLong:60*[total_day_left_time.text longLongValue]] forKey:kWeekday_time];
    [pendingData setObject:[NSNumber numberWithLongLong:60*[total_week_left_time.text longLongValue]] forKey:kWeekend_time];
    [pendingData setObject:[NSNumber numberWithLongLong:60*[short_time.text longLongValue]] forKey:kInteval_pause];
    [pendingData setObject:[NSNumber numberWithLongLong:60*[long_time.text longLongValue]] forKey:kInteval_break];    
    
    
//  ***test:second***    
//    [pendingData setObject:total_day_left_time.text forKey:kWeekday_time];
//    [pendingData setObject:total_week_left_time.text forKey:kWeekend_time];
//    [pendingData setObject:short_time.text forKey:kInteval_pause];
//    [pendingData setObject:long_time.text forKey:kInteval_break];
//  ***test:second*** 
    
    [pendingData setObject:[NSNumber numberWithInt:13] forKey:kPause_duration];
    [pendingData setObject:[NSNumber numberWithInt:480] forKey:kBreak_duration];
    
    NSTimeInterval interval = [[NSDate date] timeIntervalSince1970]; 
    NSString *dateStr = [NSString stringWithFormat:@"%.0f", interval];
    [pendingData setObject:dateStr forKey:kLastUpdate];
    
    [pendingData setObject:@"true" forKey:@"no_sign"];
    
    NSString* path = @"api/v1/owners/save.json";
    NSMutableString *urlBuf = [[NSMutableString alloc]init];
    [urlBuf appendString:[Kittypad getServerUrl]];
    [urlBuf appendString:path];
    NSURL* url =[NSURL URLWithString:urlBuf];
    
    
    NSString* key = [Kittypad getKey];
    NSString* secret = [Kittypad getSecret];
    
    ASIFormDataRequest  *request = [[[ASIFormDataRequest alloc] initWithURL:url] autorelease];
//    [request addPostValue:key forKey:@"key"];
    [pendingData setObject:key forKey:@"key"];
    
    
    request = [[KPData instance] addRequestWithDitionary:request withDictionary:pendingData];
    NSString* sig = [[[KPData instance] getSignitureWithPath:path secret:secret method:@"POST" query:pendingData]retain];
    
    [request addPostValue:sig forKey:@"signature"];
    [request setDelegate:self];
    [request startSynchronous];
    
    [urlBuf release];

}

- (void)requestFailed:(ASIHTTPRequest *)request
{
    NSLog(@"requestFailed");
    NSError *error = [request error];
    NSLog(@"%@",[error description]);
    indicatorView.hidden = YES;
    [indicatorView stopAnimating];
    
    [[[[UIAlertView alloc]
       initWithTitle:@"Failed"
       message:@"Save profile Failed !!!"
       delegate:nil
       cancelButtonTitle:@"Ok"
       otherButtonTitles:nil] autorelease] show];

}

- (void)requestFinished:(ASIHTTPRequest *)request
{
    // Use when fetching text data
    NSLog(@"requestFinished");
    NSString *responseString = [request responseString];
    NSLog(@"%@", responseString);
    
    NSError *parse_error = nil;
    NSData* data = [responseString dataUsingEncoding:NSUTF8StringEncoding];
    NSDictionary* root = [[CJSONDeserializer deserializer] deserializeAsDictionary:data error:&parse_error];
    
    if(request.responseStatusCode == 200){
        if(root!=nil){
            BOOL error = [[root objectForKey:@"error"] boolValue];
            if (error ==NO) {
                [[KPData instance] setKPValueWithDictonary:pendingData];
                
                [[KPData instance] setKPValue:[NSNumber numberWithLongLong:60*[total_day_left_time.text longLongValue]] withKey:kWeekday_time_left];
                [[KPData instance] setKPValue:[NSNumber numberWithLongLong:60*[total_week_left_time.text longLongValue]] withKey:kWeekend_time_left];
                [[KPData instance] setKPValue:[NSNumber numberWithLongLong:60*[short_time.text longLongValue]] withKey:kInteval_pause_left];
                [[KPData instance] setKPValue:[NSNumber numberWithLongLong:60*[long_time.text longLongValue]] withKey:kInteval_break_left];
                
                NSLog(@"%lld", 60 * [total_day_left_time.text longLongValue]);
                NSLog(@"%lld", 60 * [total_week_left_time.text longLongValue]);
                                NSLog(@"%lld", 60 * [short_time.text longLongValue]);
                                NSLog(@"%lld", 60 * [long_time.text longLongValue]);
                
                

//  ***test:second***                 
//                [[KPData instance] setKPValue:total_day_left_time.text withKey:kWeekday_time_left];
//                [[KPData instance] setKPValue:total_week_left_time.text withKey:kWeekend_time_left];
//                [[KPData instance] setKPValue: short_time.text withKey:kInteval_pause_left];
//                [[KPData instance] setKPValue: long_time.text withKey:kInteval_break_left];
//  ***test:second*** 
                
                UIAlertView *message = [[UIAlertView alloc] initWithTitle:@"Yeah!"  
                                                                  message:[NSString stringWithFormat:@"add/edit %@ to server , Thanks!"  , emailField.text]
                                                                 delegate:self  
                                                        cancelButtonTitle:@"OK"  
                                                        otherButtonTitles:nil];  
                [message show];  
                [message release]; 
            } else
            {
                NSLog(@"error == ture ><");
                
                NSString *errorMessage = [NSString stringWithFormat:@"%@", [root objectForKey:@"messages"]];
                if ([errorMessage isEqualToString:@"(\n    \"wrong email and password\"\n)"]) {
                    [[[[UIAlertView alloc]
                       initWithTitle:@"Failed"
                       message:@"wrong password !!!"
                       delegate:nil
                       cancelButtonTitle:@"Ok"
                       otherButtonTitles:nil] autorelease] show];
                }
            }
        }
    }
    indicatorView.hidden = YES;
    [indicatorView stopAnimating];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
	[Kittypad dismissDashboard];
}

- (IBAction) changeDate:(id)sender
{
    if (isUpdate) {
        return;
    }
    
    NSCalendar *sysCalendar = [NSCalendar currentCalendar];
    NSDateComponents *conversionInfo = [sysCalendar components:NSYearCalendarUnit fromDate:birthday.date  toDate:[NSDate date]  options:0];
    NSLog(@"Conversion: %dyear",[conversionInfo year]);
    
    int year = [conversionInfo year];
    int totalWeekdayMin = 10 + year * 30;
    
    if (isPad) {
        totalWeekdayMin = totalWeekdayMin > 180 ? 180 : totalWeekdayMin;
    }
    else {
        totalWeekdayMin = totalWeekdayMin > 360 ? 360 : totalWeekdayMin;
    }
    total_day_left_time.text = [NSString stringWithFormat:@"%d", totalWeekdayMin];
    total_week_left_time.text = [NSString stringWithFormat:@"%d", totalWeekdayMin + 60];
}


@end
