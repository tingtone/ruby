//
//  PauseController.m
//  KittypadSDK
//
//  Created by de meng on 7/8/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "PauseController.h"
#import "Kittypad.h"
#import "Kittypad+internal.h"
#import "KittyUtil.h"
#import "TimeMgr.h"

@implementation PauseController

@synthesize myBackMusic, changeSettingButton, pauseButton, imageView, type, isChangeSettingButtonPress;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)dealloc
{
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    if([[Kittypad getBreakDelegate] respondsToSelector:@selector(onPause)]) {
        [[Kittypad getBreakDelegate]onPause];
    }
    
    NSLocale* currentLocale = [NSLocale currentLocale];
//    NSLog(@"%@", [currentLocale localeIdentifier]);
    
    //type 1:pause 2:break
    if (type == 1) {
        pauseButton.hidden = TRUE;
        if (isPad) {
            if ([[currentLocale localeIdentifier] isEqualToString:@"zh_CN"]) {
                imageView.image = [UIImage imageWithContentsOfFile:[[Kittypad getResourceBundle] pathForResource:@"ipad_protecteyes_background_cn" ofType:@"png"]];
                [changeSettingButton setImage:[UIImage imageWithContentsOfFile:[[Kittypad getResourceBundle] pathForResource:@"ipad_changesetting_botton_normal_cn" ofType:@"png"]] forState:UIControlStateNormal];
            }
            else {
                imageView.image = [UIImage imageWithContentsOfFile:[[Kittypad getResourceBundle] pathForResource:@"ipad_protecteyes_background_en" ofType:@"png"]];
                [changeSettingButton setImage:[UIImage imageWithContentsOfFile:[[Kittypad getResourceBundle] pathForResource:@"ipad_changesetting_botton_normal_en" ofType:@"png"]] forState:UIControlStateNormal];
            }
        }
        else {
            self.view.frame = CGRectMake(0.f, 0.f, 200.f, 200.f);
            imageView.frame = CGRectMake(0.f, 0.f, 200.f, 200.f);
            changeSettingButton.frame = CGRectMake(-110.f, 100.f, 300.f, 150.f);
            if ([[currentLocale localeIdentifier] isEqualToString:@"zh_CN"]) {
                imageView.image = [UIImage imageWithContentsOfFile:[[Kittypad getResourceBundle] pathForResource:@"iphone_protecteyes_background_cn" ofType:@"png"]];
                [changeSettingButton setImage:[UIImage imageWithContentsOfFile:[[Kittypad getResourceBundle] pathForResource:@"iphone_changesetting_botton_normal_cn" ofType:@"png"]] forState:UIControlStateNormal];
            }
            else {
                imageView.image = [UIImage imageWithContentsOfFile:[[Kittypad getResourceBundle] pathForResource:@"iphone_protecteyes_background_en" ofType:@"png"]];
                [changeSettingButton setImage:[UIImage imageWithContentsOfFile:[[Kittypad getResourceBundle] pathForResource:@"iphone_changesetting_botton_normal_en" ofType:@"png"]] forState:UIControlStateNormal];
            }
        }
    }
    else if(type == 2){
        pauseButton.hidden = FALSE;
        if (isPad) {
            if ([[currentLocale localeIdentifier] isEqualToString:@"zh_CN"]) {
                imageView.image = [UIImage imageWithContentsOfFile:[[Kittypad getResourceBundle] pathForResource:@"ipad_break_background_cn" ofType:@"png"]];
                [changeSettingButton setImage:[UIImage imageWithContentsOfFile:[[Kittypad getResourceBundle] pathForResource:@"ipad_changesetting_botton_normal_cn" ofType:@"png"]] forState:UIControlStateNormal];
                [pauseButton setImage:[UIImage imageWithContentsOfFile:[[Kittypad getResourceBundle] pathForResource:@"ipad_pause_botton_normal_cn" ofType:@"png"]] forState:UIControlStateNormal];
            }
            else {
                imageView.image = [UIImage imageWithContentsOfFile:[[Kittypad getResourceBundle] pathForResource:@"ipad_break_background_en" ofType:@"png"]];
                [changeSettingButton setImage:[UIImage imageWithContentsOfFile:[[Kittypad getResourceBundle] pathForResource:@"ipad_changesetting_botton_normal_en" ofType:@"png"]] forState:UIControlStateNormal];
                [pauseButton setImage:[UIImage imageWithContentsOfFile:[[Kittypad getResourceBundle] pathForResource:@"ipad_pause_botton_normal_en" ofType:@"png"]] forState:UIControlStateNormal];
            }
        }
        else {
            self.view.frame = CGRectMake(0.f, 0.f, 200.f, 200.f);
            imageView.frame = CGRectMake(0.f, 0.f, 200.f, 200.f);
            changeSettingButton.frame = CGRectMake(-110.f, 100.f, 300.f, 150.f);
            pauseButton.frame = CGRectMake(10.f, 100.f, 300.f, 150.f);
            if ([[currentLocale localeIdentifier] isEqualToString:@"zh_CN"]) {
                imageView.image = [UIImage imageWithContentsOfFile:[[Kittypad getResourceBundle] pathForResource:@"iphone_break_background_cn" ofType:@"png"]];
                [changeSettingButton setImage:[UIImage imageWithContentsOfFile:[[Kittypad getResourceBundle] pathForResource:@"iphone_changesetting_botton_normal_cn" ofType:@"png"]] forState:UIControlStateNormal];
                [pauseButton setImage:[UIImage imageWithContentsOfFile:[[Kittypad getResourceBundle] pathForResource:@"iphone_pause_botton_normal_cn" ofType:@"png"]] forState:UIControlStateNormal];
            }
            else {
                imageView.image = [UIImage imageWithContentsOfFile:[[Kittypad getResourceBundle] pathForResource:@"iphone_break_background_en" ofType:@"png"]];
                [changeSettingButton setImage:[UIImage imageWithContentsOfFile:[[Kittypad getResourceBundle] pathForResource:@"iphone_changesetting_botton_normal_en" ofType:@"png"]] forState:UIControlStateNormal];
                [pauseButton setImage:[UIImage imageWithContentsOfFile:[[Kittypad getResourceBundle] pathForResource:@"iphone_pause_botton_normal_en" ofType:@"png"]] forState:UIControlStateNormal];
            }
        }
    }
    
    
    NSString *musicFilePath = [[Kittypad getResourceBundle] pathForResource:@"start" ofType:@"mp3"];
    NSURL *musicURL = [[NSURL alloc] initFileURLWithPath:musicFilePath];  
    
    AVAudioPlayer *thePlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:musicURL error:nil];
    self.myBackMusic = thePlayer;
    
    [musicURL release];
    [thePlayer release];
    
    isChangeSettingButtonPress = FALSE;
    
    [myBackMusic prepareToPlay];
    [myBackMusic setVolume:1];   
    myBackMusic.numberOfLoops = -1; //loop
    [myBackMusic play];
    
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
    
    [myBackMusic stop];
    self.changeSettingButton = nil;
    self.pauseButton = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
	return YES;
}

- (IBAction) changeSetting:(id)sender
{
    isChangeSettingButtonPress = TRUE;
    
    [myBackMusic stop];
    [[self view] removeFromSuperview];
    [Kittypad presentDashboard];
    UITabBarController *tabController = [Kittypad getTabController];
    [tabController setSelectedIndex:0];
}

- (IBAction) pause:(id)sender
{
    [myBackMusic stop];
    [[self view] removeFromSuperview];
    
    if([[Kittypad getBreakDelegate] respondsToSelector:@selector(onResume)]) {
        [[Kittypad getBreakDelegate]onResume];
    }
    
    [[TimeMgr instance]startTimer];
}

- (void) stopMusic
{
    [myBackMusic stop];
    
    if (!isChangeSettingButtonPress) {
        [[TimeMgr instance]startTimer];
        
        if([[Kittypad getBreakDelegate] respondsToSelector:@selector(onResume)]) {
            [[Kittypad getBreakDelegate]onResume];
        }
    }
}

@end
