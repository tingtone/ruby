//
//  KittypadCPP.h
//  KittypadSDK
//
//  Created by de meng on 7/24/11.
//  Copyright 2011 Kittypad. All rights reserved.
//

#ifndef KITTYPAD_CPP_H_
#define KITTYPAD_CPP_H_

class KittypadCPP {
public:
    static void start();
    static void postScore(int score);
};

#endif /* KITTYPAD_CPP_H_ */