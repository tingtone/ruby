#import <Foundation/Foundation.h>


@protocol KittypadDelegate <NSObject>

// display message and close the program
// Game dev must implement this feature
- (void)onClose:(NSString*)message;

@end
