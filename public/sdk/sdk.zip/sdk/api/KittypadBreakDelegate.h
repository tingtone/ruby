//
//  KittypadBreakDelegate.h
//  KittypadSDK
//
//  Created by de meng on 7/18/11.
//  Copyright 2011 Kittypad. All rights reserved.
//

#import <Foundation/Foundation.h>


@protocol KittypadBreakDelegate <NSObject>

- (void)onPause;
- (void)onResume;

@end
