//
//  SKProduct+LocalizedPrice.h
//  MathNijia
//
//  Created by Peng Lingyun on 4/3/11.
//  Copyright 2011 kittypad. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <StoreKit/StoreKit.h>

@interface SKProduct (LocalizedPrice)

@property (nonatomic, readonly) NSString *localizedPrice;

@end
