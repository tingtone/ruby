//
//  PurchaseLayer.m
//  MathNijia
//
//  Created by Peng Lingyun on 4/5/11.
//  Copyright 2011 kittypad. All rights reserved.
//

#import "PurchaseLayer.h"
#import "InAppPurchaseManager.h"
#import "SKProduct+LocalizedPrice.h"

@implementation PurchaseLayer

- (id) initWithColor:(ccColor4B)color width:(GLfloat)w  height:(GLfloat) h
{
	if( (self=[super initWithColor:color width:w height:h]) ) {
        productLabel = [CCLabelTTF labelWithString:[InAppPurchaseManager sharedManager].proUpgradeProduct.localizedTitle fontName:@"Arial" fontSize:20];
        productLabel.position = ccp(200, 300);
        [self addChild:productLabel];
        
        
        priceLabel = [CCLabelTTF labelWithString:[[InAppPurchaseManager sharedManager].proUpgradeProduct localizedPrice] fontName:@"Arial" fontSize:20];
        priceLabel.position = ccp(200, 100);
        [self addChild:priceLabel];
        
        CCMenuItemFont *buyItem = [CCMenuItemFont itemFromString: @"Buy" target:self selector:@selector(onBuy:)];
        CCMenuItemFont *cancelItem = [CCMenuItemFont itemFromString: @"Cancel" target:self selector:@selector(onCancel:)];
        
        CCMenu* menu = [CCMenu menuWithItems: buyItem, cancelItem, nil];
        menu.position = ccp(200, 50);
        [menu alignItemsHorizontallyWithPadding:100];
        [self addChild:menu];
    }
    return self;
}


-(void)onBuy:(NSObject*)sender
{    
    // TODO hide cancel menu
    [[InAppPurchaseManager sharedManager] purchaseProUpgrade];
    [self removeFromParentAndCleanup:YES];
}

-(void)onCancel:(NSObject*)sender
{
    // TODO: able to cancel on going payment
    [self removeFromParentAndCleanup:YES];
}

@end
