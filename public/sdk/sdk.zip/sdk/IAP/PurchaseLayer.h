//
//  PurchaseLayer.h
//  MathNijia
//
//  Created by Peng Lingyun on 4/5/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "cocos2d.h"


@interface PurchaseLayer : CCLayerColor {
    CCLabelTTF* productLabel;
    CCLabelTTF* priceLabel;
}

-(void)onBuy:(NSObject*)sender;
-(void)onCancel:(NSObject*)sender;

@end
