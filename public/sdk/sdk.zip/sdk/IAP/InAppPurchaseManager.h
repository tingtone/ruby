//
//  InAppPurchaseManager.h
//  MathNijia
//
//  Created by Peng Lingyun on 4/3/11.
//  Copyright 2011 kittypad. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <StoreKit/StoreKit.h>
#import "PurchaseLayer.h"

#define kInAppPurchaseManagerProductsFetchedNotification @"kInAppPurchaseManagerProductsFetchedNotification"
#define kInAppPurchaseManagerTransactionFailedNotification @"kInAppPurchaseManagerTransactionFailedNotification"
#define kInAppPurchaseManagerTransactionSucceededNotification @"kInAppPurchaseManagerTransactionSucceededNotification"

@interface InAppPurchaseManager : NSObject <SKProductsRequestDelegate, SKPaymentTransactionObserver>{
	SKProduct *proUpgradeProduct;
    SKProductsRequest *productsRequest;
    BOOL isProUpgradePurchased;
    NSString* iapProduct;
    CCNode* parentLayer;
    //CCSprite* spinner;
}

@property(nonatomic, readonly) SKProduct* proUpgradeProduct;
@property(nonatomic) BOOL isProUpgradePurchased;

+(InAppPurchaseManager*) sharedManager;

- (void)onPurchase:(CCNode*)parent product:(NSString*) product;
- (void) onAppProductReady;

- (void)loadStore;
- (BOOL)canMakePurchases;
- (void)purchaseProUpgrade;


@end
